package portal.controller;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.inject.Inject;
import org.primefaces.component.menuitem.MenuItem;
import org.primefaces.component.submenu.Submenu;
import org.primefaces.model.DefaultMenuModel;
import org.primefaces.model.MenuModel;
import util.FacesUtils;
import util.Util;
import util.conector.backend.Account;
import util.conector.backend.Session;



@ManagedBean(name="portalController")
public class PortalController implements ActionListener{
	
	@Inject
	Util util;
	
	
	@PostConstruct
	public void init() {
		Session session = util.getSession();
		if(session==null){
			FacesUtils.redirect("portal/quickregister/content.jsf");
		}
		else{
			account = session.getAccount();
			setMenuSettings();
			if(!(FacesUtils.getSessionAttribute("content")==null)){
				content = (String) FacesUtils.getSessionAttribute("content");
			}
		}
	}

	private Account account;
	public Account getAccount() {	
		return account;
	}

	private String content;	
	public String getContent() {
		return content;
	}
	
	
	//---------------------------------------
	private String logo = "/images/logo.png";	
	public String getLogo()  {
		 return  logo;
	}
		
	private MenuModel  model = new  DefaultMenuModel();
	
	public MenuModel getModel() {		
		return model;		
	}
	
	public void setMenuSettings(){
		
		if(account.getRole().getName().toLowerCase().equals("tenant")){
			
			content = "security/tenant/myaccount/content.xhtml";
			
			Submenu  sm1  =  new  Submenu();
			sm1.setLabel("PBX Setup");
			
			MenuItem  sm1m1  =  new  MenuItem();
			sm1m1.setValue("Users");		
			sm1m1.setId("sm1m1");
			sm1m1.setIcon("ui-icon-person");
			sm1m1.setAjax(false);			
			sm1m1.addActionListener(this);	
			sm1m1.setTarget("security/tenant/user/content.xhtml");
			 
						
			MenuItem  sm1m2  =  new  MenuItem();
			sm1m2.setValue("Groups");		
			sm1m2.setId("sm1m2");
			sm1m2.setIcon("ui-icon-gear");
			sm1m2.setAjax(false);			
			sm1m2.addActionListener(this);	
			sm1m2.setTarget("pbx/tenant/queue/content.xhtml");	
			
					
			MenuItem  sm1m3  =  new  MenuItem();
			sm1m3.setValue("Settings");		
			sm1m3.setId("m9");
			sm1m3.setIcon("ui-icon-wrench");
			sm1m3.setAjax(false);			
			sm1m3.addActionListener(this);	
			sm1m3.setTarget("pbx/tenant/settings/content.xhtml");	
			
			MenuItem  sm1m4  =  new  MenuItem();
			sm1m4.setValue("My Account");		
			sm1m4.setId("m10");
			sm1m4.setIcon("ui-icon-contact");
			sm1m4.setAjax(false);
			sm1m4.addActionListener(this);	
			sm1m4.setTarget("security/tenant/myaccount/content.xhtml");	
			
			sm1.getChildren().add(sm1m1);
			sm1.getChildren().add(sm1m2);	
			sm1.getChildren().add(sm1m3);
			sm1.getChildren().add(sm1m4);	
			
			//----------------------------------------------
			
			Submenu  sm2  =  new  Submenu();
			sm2.setLabel("Reports");
			
			MenuItem  sm2m1  =  new  MenuItem();
			sm2m1.setValue("Call History");		
			sm2m1.setId("sm2m1");
			sm2m1.setIcon("ui-icon-document");
			sm2m1.setAjax(false);			
			sm2m1.addActionListener(this);	
			sm2m1.setTarget("pbx/tenant/cdr/content.xhtml");
			
			MenuItem  sm2m2  =  new  MenuItem();
			sm2m2.setValue("Group Report");		
			sm2m2.setId("sm2m2");
			sm2m2.setIcon("ui-icon-document");
			sm2m2.setAjax(false);			
			sm2m2.addActionListener(this);	
			sm2m2.setTarget("pbx/tenant/queuereport/content.xhtml");	
			
			sm2.getChildren().add(sm2m1);
			sm2.getChildren().add(sm2m2);
			
			//----------------------------------------------
			
			model.addSubmenu(sm1);
			model.addSubmenu(sm2);
	
		}
		
	
	}

	@Override
	public void processAction(ActionEvent event) throws AbortProcessingException {
		 MenuItem menu = (MenuItem)event.getSource();
		 content = menu.getTarget();
		 FacesUtils.setSession("content", content);
	}	
	
	public void doLogout() {
		util.closeSession();
		FacesUtils.redirect("portal/quickregister/content.jsf");
	}

}