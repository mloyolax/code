package portal.controller;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.inject.Inject;
import org.primefaces.component.menuitem.MenuItem;
import org.primefaces.component.submenu.Submenu;
import org.primefaces.model.DefaultMenuModel;
import org.primefaces.model.MenuModel;
import util.FacesUtils;
import util.Util;
import util.conector.security.Account;
import util.conector.security.Session;


@ManagedBean(name="portalController")
public class PortalController implements ActionListener{
	
	@Inject
	Util util;
	
	
	@PostConstruct
	public void init() {
		Session session = util.getSession();
		if(session==null){
			FacesUtils.redirect("portal/quickregister/content.jsf");
		}
		else{
			account = session.getAccount();
			setMenuSettings();
			if(!(FacesUtils.getSessionAttribute("content")==null)){
				content = (String) FacesUtils.getSessionAttribute("content");
			}
		}
	}

	private Account account;
	public Account getAccount() {	
		return account;
	}

	private String content;	
	public String getContent() {
		return content;
	}
	
	
	//---------------------------------------
	private String logo = "/images/logo.png";	
	public String getLogo()  {
		 return  logo;
	}
		
	private MenuModel  model = new  DefaultMenuModel();
	
	public MenuModel getModel() {		
		return model;		
	}
	
	public void setMenuSettings(){
		
		if(account.getRole().getName().toLowerCase().equals("tenant")){
			
			content = "security/tenant/myaccount/content.xhtml";
			
			Submenu  sm1  =  new  Submenu();
			sm1.setLabel("Security Settings");
			
			MenuItem  sm1m1  =  new  MenuItem();
			sm1m1.setValue("Extensions");		
			sm1m1.setId("sm1m1");
			sm1m1.setAjax(false);			
			sm1m1.addActionListener(this);	
			sm1m1.setTarget("superadmin/account/content.xhtml");	
			
			MenuItem  sm1m2  =  new  MenuItem();
			sm1m2.setValue("Queues");		
			sm1m2.setId("sm1m2");
			sm1m2.setAjax(false);			
			sm1m2.addActionListener(this);	
			sm1m2.setTarget("superadmin/organization/content.xhtml");	
			

			MenuItem  sm1m3  =  new  MenuItem();
			sm1m3.setValue("Call History");		
			sm1m3.setId("sm1m3");
			sm1m3.setAjax(false);			
			sm1m3.addActionListener(this);	
			sm1m3.setTarget("superadmin/role/content.xhtml");
			
			MenuItem  sm1m4  =  new  MenuItem();
			sm1m4.setValue("Queue Report");		
			sm1m4.setId("sm1m4");
			sm1m4.setAjax(false);			
			sm1m4.addActionListener(this);	
			sm1m4.setTarget("superadmin/myaccount/content.xhtml");	
			
			MenuItem  sm1m5  =  new  MenuItem();
			sm1m5.setValue("My Account");		
			sm1m5.setId("sm1m5");
			sm1m5.setAjax(false);			
			sm1m5.addActionListener(this);	
			sm1m5.setTarget("security/tenant/myaccount/content.xhtml");	
			
			sm1.getChildren().add(sm1m1);
			sm1.getChildren().add(sm1m2);	
			sm1.getChildren().add(sm1m3);	
			sm1.getChildren().add(sm1m4);
			sm1.getChildren().add(sm1m5);
			
			
			model.addSubmenu(sm1);
	
		}
		
	
	}

	@Override
	public void processAction(ActionEvent event) throws AbortProcessingException {
		 MenuItem menu = (MenuItem)event.getSource();
		 content = menu.getTarget();
		 FacesUtils.setSession("content", content);
	}	
	
	public void doLogout() {
		util.closeSession();
		FacesUtils.redirect("portal/quickregister/content.jsf");
	}

}