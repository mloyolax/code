package portal.controller;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;
import util.FacesUtils;
import util.Util;
import util.conector.security.Account;
import util.conector.security.Tenant;


@ManagedBean(name="portalQuickRegister")
public class QuickRegisterController{
	
	@Inject
	Util util;
	
	Account account = new Account();
	Tenant tenant = new Tenant();

	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}

	public Tenant getTenant() {
		return tenant;
	}
	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}
	
	@PostConstruct
	public void LoadDefault(){
		if(util.getSession()!=null){	
			FacesUtils.redirect("../../index.jsf");
		}
	}
	
	public void tenantRegister() {
		String token = util.getSecurityWS().tenantRegister(tenant, account) ;	
		if(token != null){
			FacesUtils.setCookie("portaltoken", token);
			FacesUtils.redirect("../../index.jsf");
		}
		else {
			FacesUtils.addErrorMessage("public","User/Password Not Found","sss");
		}
	}
	
	public void tenantLogin() {
		String token = util.getSecurityWS().tenantLogin(account.getEmail(), account.getPassword()) ;	
		if(token != null){
			FacesUtils.setCookie("portaltoken", token);
			FacesUtils.redirect("../../index.jsf");
		}
		else {
			FacesUtils.addErrorMessage("public","User/Password Not Found","sss");
		}
	}
		
	public void tenantRemember(){
		util.getSecurityWS().tenantRemember(account.getEmail());
	}
	

}