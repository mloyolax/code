package portal.controller;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;
import util.FacesUtils;
import util.Util;
import util.conector.backend.Account;
import util.conector.backend.Session;
import util.conector.backend.Tenant;



@ManagedBean(name="portalLogin")
public class LoginController{
	
	@Inject
	Util util;
	
	private Account account = new Account();
	private Tenant tenant = new Tenant();

	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}	
	public Tenant getOrganization() {
		return tenant;
	}
	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}
	
	@PostConstruct
	public void LoadDefault(){	
		Session value = util.getSession();	
		if(value!=null){	
			FacesUtils.redirect("../../index.jsf");
		}
	}
				
	public void doAccountLogin() {
		String token = util.getService().accountLogin(account.getEmail(), account.getPassword()) ;	
		if(token != null){
			FacesUtils.setCookie("portaltoken", token);
			FacesUtils.redirect("../index.jsf");
		}
		else {
			FacesUtils.addErrorMessage("public","User/Password Not Found","sss");
		}
	}
	


}