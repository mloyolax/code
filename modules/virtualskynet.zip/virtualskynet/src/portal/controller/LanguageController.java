package portal.controller;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import util.FacesUtils;

@SessionScoped
@ManagedBean(name="portalLanguage")
public class LanguageController{
	
		
	public LanguageController(){
		String sys = (String) FacesUtils.getLocale();
		locale = sys;		
	}
	
	private Map<String,Object> items1;	
	
	public Map<String, Object> getItems1() {
		items1 = new LinkedHashMap<String,Object>();
		items1.put("English", "en");
		items1.put("Espanish", "es");
		items1.put("Portuguesse", "pt");
		return items1;
	}
		
	public void localeChangeListener(){
		System.out.println("CHANGE" + locale);
		//FacesUtils.setLocale(locale);
	}
	
	//--------------------------------------------------
	private String locale="en";			
	
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	

}