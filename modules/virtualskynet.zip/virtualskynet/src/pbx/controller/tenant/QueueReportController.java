package pbx.controller.tenant;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import org.primefaces.model.chart.CartesianChartModel;
import org.primefaces.model.chart.ChartSeries;
import util.Util;
import util.conector.backend.Queue;
import util.conector.backend.QueueReport;
import util.conector.backend.QueueReportTotal;
import util.conector.backend.Tenant;


@SessionScoped
@ManagedBean(name="pbxTenantQueueReport")
public class QueueReportController{
	
	@Inject
	Util util;
		
	Tenant tenant;
	
	//-------------------------------------------------------------
	List<Queue> queues; 
	public List<Queue> getQueues() {
		return queues;
	}
	
	//-------------------------------------------------------------
	
	String selectedqueue; 
	public String getSelectedqueue() {
		return selectedqueue;
	}
	public void setSelectedqueue(String selectedqueue) {
		this.selectedqueue = selectedqueue;
	}
	
	private Map<String,String> items;	
	public Map<String, String> getItems() {
		items = new LinkedHashMap<String,String>();
		Iterator<Queue> queueIt = queues.iterator();
		while(queueIt.hasNext()){
			Queue queue = queueIt.next();
			items.put(queue.getLabel(), queue.getName());
			
		}
		return items;
	}
	
	//-------------------------------------------------------------	
	
	String option = "report.xhtml";
	public String getOption() {
		refreshQueues();
		return option;
	}		
	
	//-------------------------------------------------------------
	
	public void refreshQueues() {
		tenant = util.getSession().getAccount().getTenant();
		queues = util.getService().listQueuesByTenant(tenant.getId());	
		
		try {
			SimpleDateFormat formatoHora = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatoTotal = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			startDate = formatoTotal.parse(formatoHora.format(new Date())+" 00:00:00");
			endDate = formatoTotal.parse(formatoHora.format(new Date())+" 23:59:59");
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		
	}	
	
	//-------------------------------------------------------------
	
	private List<QueueReport> reports  = new ArrayList<QueueReport>();
	private QueueReportTotal reportTotal = new QueueReportTotal();
	private Date startDate;
	private Date endDate;
	
	public List<QueueReport> getReports() {
		return reports;
	}	
	public void setReports(List<QueueReport> reports) {
		this.reports = reports;
	}	
	public QueueReportTotal getReportTotal() {
		return reportTotal;
	}
	public void setReportTotal(QueueReportTotal reportTotal) {
		this.reportTotal = reportTotal;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	//-------------------------------------------------------------
	private CartesianChartModel chart = new CartesianChartModel();
	public CartesianChartModel getChart() {
		return chart;
	}
	public void setChart(CartesianChartModel chart) {
		this.chart = chart;
	}	
	
	//-------------------------------------------------------------
	public void onReport() {
		option = "report.xhtml";
	}	
    public void onStats() {
    	option = "stats.xhtml";
	}    
    	
	public void doReport() {
		setReports(util.getService().getACDReport(getSelectedqueue(),startDate.getTime(), endDate.getTime()));
		setReportTotal(util.getService().getTotals(getSelectedqueue(),startDate.getTime(), endDate.getTime()));	
		option = "report.xhtml";
    }
	public void doStats() {
		
		CartesianChartModel chart = new CartesianChartModel();
		
		ChartSeries enterqueueChart = new ChartSeries();  
		enterqueueChart.setLabel("Conected");
		
		ChartSeries connectChart = new ChartSeries();  
		connectChart.setLabel("Answered");
		
		ChartSeries abandonChart = new ChartSeries();  
		abandonChart.setLabel("Abandon");

		List<QueueReport> inbounds = util.getService().getACDReport(getSelectedqueue(),startDate.getTime(), endDate.getTime());	
		Iterator<QueueReport> init  = inbounds.iterator();
		while(init.hasNext()){			
			QueueReport report = init.next();
			if(report.getEnterqueue()>0){
				enterqueueChart.set(report.getDateRange().substring(0,3), report.getEnterqueue());
				connectChart.set(report.getDateRange(), report.getConnect()); 
				abandonChart.set(report.getDateRange(), report.getAbandon());
			}
			
		}
		chart.addSeries(enterqueueChart);
		chart.addSeries(connectChart);
		chart.addSeries(abandonChart);
		
		setChart(chart);
		
		option = "stats.xhtml";
    }
		
    
}
