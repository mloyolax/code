package pbx.controller.tenant;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import util.FacesUtils;
import util.Util;
import util.conector.backend.Settings;
import util.conector.backend.Tenant;


@SessionScoped
@ManagedBean(name="pbxTenantSettings")
public class SettingsController{
		
	@Inject
	Util util;
	
	Tenant tenant;
	
	@PostConstruct
	public void init() {
		tenant = util.getSession().getAccount().getTenant();
		row = util.getService().getSettingsByTenant(tenant.getId());
		if(row==null){
			row = new Settings();
		}
	}
		
    //-------------------------------------------------------------
	Settings row;
	public Settings getRow() {
		return row;
	}
	public void setRow(Settings row) {
		this.row = row;
	}	
	
	//-------------------------------------------------------------	

	 public void onCancel() {    	
	    FacesUtils.addErrorMessage("public","Cancel!!","");	
	 }
	 
    public void doUpdate() {    	
    	util.getService().updateSettings(tenant.getId(), row);
    	FacesUtils.addErrorMessage("public","Settings Updated!!","");	
    }
    
  	    
}
