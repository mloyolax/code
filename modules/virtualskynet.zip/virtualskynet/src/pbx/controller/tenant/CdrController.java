package pbx.controller.tenant;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import util.Util;
import util.conector.backend.Account;
import util.conector.backend.Cdr;
import util.conector.backend.Tenant;


@SessionScoped
@ManagedBean(name="pbxTenantCdr")
public class CdrController{
	
	@Inject
	Util util;
	
	Tenant tenant;
	
	
	@PostConstruct
	public void init() {
		tenant = util.getSession().getAccount().getTenant();
		data = util.getService().listCdrsByTenant(tenant.getId());
		accounts = util.getService().listUsersByTenant(tenant, 0, 0);
	}
	
	
    //-------------------------------------------------------------	
	List<Cdr> data;
	public List<Cdr> getData() {
		data = util.getService().listCdrsByTenant(tenant.getId());
		return data;
	} 
		
	List<Account> accounts; 	
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}		
	//-------------------------------------------------------------		
	private Map<String,String> items;	
	public Map<String, String> getItems() {
		items = new LinkedHashMap<String,String>();	
		if(accounts!=null){
			Iterator<Account> accounstIt = accounts.iterator();
			while(accounstIt.hasNext()){
				Account account = accounstIt.next();
				items.put(account.getName(), account.getId().toString());			
			}
		}
		return items;
	}


	//-------------------------------------------------------------
	
  	/*public void doAccount() {
  		
		if(account.getId()==0){
			//cdrreports = billingService.get
		}
		else{
			cdrs = billingService.getCDReportByOrganization(account.getOrganization().getId());
		}
	}*/
	

    
}
;