package pbx.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import org.primefaces.model.DualListModel;
import util.FacesUtils;
import util.Util;
import util.conector.pbx.Queue;
import util.conector.pbx.QueueMember;
import util.conector.security.Account;
import util.conector.security.Tenant;


@SessionScoped
@ManagedBean(name="pbxTenantQueue")
public class QueueController{	
	
	@Inject
	Util util;	

	List<Queue> data; 
	
	Tenant tenant;
	
	
	@PostConstruct
	public void init() {
		System.out.println("INIT");
		tenant = util.getSession().getAccount().getTenant();
		data = util.getPbxWS().listQueuesByTenant(tenant.getId());	
	}
		
	public List<Queue> getData() {
		init();
		return data;
	}
	
    //-------------------------------------------------------------
	Queue row; 	
	public Queue getRow() {
		return row;
	}
	public void setRow(Queue row) {
		this.row = row;
	}
	
	DualListModel<Account> members; 
	public DualListModel<Account> getMembers() {
		return members;
	}
	public void setMembers(DualListModel<Account> members) {
		this.members = members;
	}

	//-------------------------------------------------------------	
	String option = "show.xhtml";
	public String getOption() {
		return option;
	}
	
	//-------------------------------------------------------------

	private Map<String,String> items1;	
	
	public Map<String, String> getItems1() {
		items1 = new LinkedHashMap<String,String>();
		items1.put("System Default", "default");
		return items1;
	}
	//-------------------------------------------------------------

	private Map<String,String> items2;	
	
	public Map<String, String> getItems2() {
		items2 = new LinkedHashMap<String,String>();
		items2.put("Ring All", "ringall");
		items2.put("Least Recent", "leastrecent");
		items2.put("Fewest Calls", "fewestcalls");
		items2.put("Random", "random");
		items2.put("RR Memory", "rrmemory");
		items2.put("RR Ordered", "rrordered");
		items2.put("Linear", "linear");
		items2.put("Wrandom", "wrandom");
		return items2;
	}
	
	
	//-------------------------------------------------------------	
	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Queue();
		List<Account> src = util.getSecurityWS().listUsersByTenant(tenant, 0, 0);
        List<Account> dst = new ArrayList<Account>();        
        members = new DualListModel<Account>(src, dst); 
		option = "create.xhtml";
	}    
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
    		
    		List<Account> src = util.getSecurityWS().listUsersByTenant(tenant, 0, 0);
            List<Account> dst = new ArrayList<Account>();        
            members = new DualListModel<Account>(src, dst);    		
        	option = "update.xhtml";	
    	}
	}
    
	public void doCreate() {
		List<Account> accounts = members.getTarget();
		Iterator<Account> it =  accounts.iterator();
		row = util.getPbxWS().addQueue(tenant.getId(), row);
		row.setName(row.getLabel());
		util.getPbxWS().updateQueue(row);

		while(it.hasNext()){
			Account account = it.next();			
			QueueMember queuemember = new QueueMember();
		    queuemember.setQueueName(row.getName());
		    queuemember.setMembername(account.getUsername());
		    queuemember.setInterfaceI("SIP/" + account.getUsername());
		    queuemember.setUniqueid(account.getUsername());
		    queuemember.setQueue(row);
		    util.getPbxWS().addQueuemember(account.getId(), queuemember);
		}		
		option = "show.xhtml";
    }
	
	public void doUpdate() {
		util.getPbxWS().deleteQueuemembersByQueue(row);
		List<Account> accounts = members.getTarget();
		Iterator<Account> it =  accounts.iterator();
		row = util.getPbxWS().updateQueue(row);
		row.setName(row.getLabel());
		util.getPbxWS().updateQueue(row);

		while(it.hasNext()){
			Account account = it.next();			
			QueueMember queuemember = new QueueMember();
		    queuemember.setQueueName(row.getName());
		    queuemember.setMembername(account.getUsername());
		    queuemember.setInterfaceI("SIP/" + account.getUsername());
		    queuemember.setUniqueid(account.getUsername());
		    queuemember.setQueue(row);
		    util.getPbxWS().addQueuemember(account.getId(), queuemember);
		}		
		option = "show.xhtml";
    }
		
	public void doDelete() {
		util.getPbxWS().deleteQueue(row.getId());
		option = "show.xhtml";
    }

}
