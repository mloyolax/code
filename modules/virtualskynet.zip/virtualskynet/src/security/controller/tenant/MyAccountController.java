package security.controller.tenant;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import util.FacesUtils;
import util.Util;
import util.conector.security.Account;


@SessionScoped
@ManagedBean(name="securityTenantMyaccount")
public class MyAccountController{
		
	@Inject
	Util util;
	
	@PostConstruct
	public void init() {
		refreshData();	
	}
	public void refreshData() {
		row = util.getSession().getAccount();
	}	
	
    //-------------------------------------------------------------
	Account row;
	public Account getRow() {
		return row;
	}
	public void setRow(Account row) {
		this.row = row;
	}	
	
	String oldpassword;	
	public String getOldpassword() {
		return oldpassword;
	}
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	String newpassword;
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	String renewpassword;
	public String getRenewpassword() {
		return renewpassword;
	}
	public void setRenewpassword(String renewpassword) {
		this.renewpassword = renewpassword;
	}	
	
	
	private Map<String,Object> languages;	
	
	public Map<String, Object> getLanguages() {
		languages = new LinkedHashMap<String,Object>();
		languages.put("English", "en");
		languages.put("Espanish", "es");
		languages.put("Portuguesse", "pt");
		return languages;
	}
	
	private Map<String,Object> themes;	
	
	public Map<String, Object> getThemes() {
		themes = new LinkedHashMap<String,Object>();
		themes.put("Aristo", "aristo");  
        themes.put("Black-Tie", "black-tie");  
        themes.put("Blitzer", "blitzer");  
        themes.put("Bluesky", "bluesky");  
        themes.put("Casablanca", "casablanca");  
        themes.put("Cupertino", "cupertino");  
        themes.put("Dark-Hive", "dark-hive");  
        themes.put("Dot-Luv", "dot-luv");  
        themes.put("Eggplant", "eggplant");  
        themes.put("Excite-Bike", "excite-bike");  
        themes.put("Flick", "flick");  
        themes.put("Glass-X", "glass-x");  
        themes.put("Hot-Sneaks", "hot-sneaks");  
        themes.put("Humanity", "humanity");  
        themes.put("Le-Frog", "le-frog");  
        themes.put("Midnight", "midnight");  
        themes.put("Mint-Choc", "mint-choc");  
        themes.put("Overcast", "overcast");  
        themes.put("Pepper-Grinder", "pepper-grinder");  
        themes.put("Redmond", "redmond");  
        themes.put("Rocket", "rocket");  
        themes.put("Sam", "sam");  
        themes.put("Smoothness", "smoothness");  
        themes.put("South-Street", "south-street");  
        themes.put("Start", "start");  
        themes.put("Sunny", "sunny");  
        themes.put("Swanky-Purse", "swanky-purse");  
        themes.put("Trontastic", "trontastic");  
        themes.put("UI-Darkness", "ui-darkness");  
        themes.put("UI-Lightness", "ui-lightness");  
        themes.put("Vader", "vader");  
		return themes;
	}
	
	
	//-------------------------------------------------------------	
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------	

	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onUpdate() {
		option = "update.xhtml";
	}
    public void onChangePassword() {
		option = "password.xhtml";
	} 
     
    public void doUpdate() {    	
    	if(row.getEmail().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Email!!","");
    	}
    	else{		
    		util.getSecurityWS().updateAccount(row);
    		FacesUtils.addErrorMessage("public","Account Updated!!","");
    		option = "show.xhtml";
    	}		
    }
    
    public void doChangePassword() {    	
    	if(!oldpassword.equals(row.getPassword())){
        	FacesUtils.addErrorMessage("public","Your Old Password dont Match!!","");
    	}
    	else{
    		if(!renewpassword.equals(newpassword)){
            	FacesUtils.addErrorMessage("public","Your New Password dont Match!!","");
        	}
    		else{
    			row.setPassword(newpassword);
    			util.getSecurityWS().updateAccount(row);
        		FacesUtils.addErrorMessage("public","Password Updated!!","");
        		option = "show.xhtml";
    		}
    	}		
    }	    
}
