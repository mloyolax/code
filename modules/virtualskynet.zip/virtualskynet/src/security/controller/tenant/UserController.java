package security.controller.tenant;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import util.FacesUtils;
import util.Util;
import util.conector.pbx.Exten;
import util.conector.security.Account;
import util.conector.security.Role;
import util.conector.security.Tenant;


@SessionScoped
@ManagedBean(name="securityTenantUser")
public class UserController{
	
	List<Account> data; 
	
	Tenant tenant;
	
	@Inject
	Util util;
		
	@PostConstruct
	public void init() {
		refreshData();	
	}
	public void refreshData() {
		tenant = util.getSession().getAccount().getTenant();
		data = util.getSecurityWS().listUsersByTenant(tenant, 0, 0);
	}	
	
	public List<Account> getData() {
		return data;
	}	
	
    //-------------------------------------------------------------
	Account row;
	public Account getRow() {
		return row;
	}
	public void setRow(Account row) {
		this.row = row;
	}	
	//-------------------------------------------------------------	
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------	

	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Account();	
		option = "create.xhtml";
	}    
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
        	option = "update.xhtml";	
    	}
	}
   
    public void doCreate() {  	
    	if(row.getUsername().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Username!!","");
    	}
    	else{
    		Role role = util.getSecurityWS().getRoleByName("user");
    		row.setTenant(tenant);
    		row.setRole(role);
    		row.setEnabled(true);
    		row = util.getSecurityWS().addAccount(row);
    		
    		//PBX Notify
			Exten exten = new Exten();
			exten.setName(row.getUsername());
			exten.setAccountcode(row.getId().toString());
			exten.setHost("dynamic");
			exten.setContext("outbound");
			exten.setDefaultuser(row.getUsername());
			exten.setSecret(row.getPassword());
			util.getPbxWS().addExten(tenant.getId(), row.getId(), exten);
			
    		option = "show.xhtml";
    	}
    }
    

    public void doUpdate() {    	
    	if(row.getUsername().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Username!!","");
    	}
    	else{
    		util.getSecurityWS().updateAccount(row);
    		
    		//PBX Notify
    		Exten exten = util.getPbxWS().getExtenByAccountcode(row.getId().toString());
    		exten.setName(row.getUsername());
    		exten.setDefaultuser(row.getUsername());
    		exten.setSecret(row.getPassword());
    		util.getPbxWS().updateExten(exten);
    		
    		option = "show.xhtml";
    	}		
    }
	
	public void doDelete() {
		if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for Delete!!","");
    	}
    	else{
    		util.getSecurityWS().deleteAccount(row.getId());
    		
    		//Notify other servies
    		util.getPbxWS().onDeleteAccount(row.getId());
    		option = "show.xhtml";
    	}		
    }
	    
}
