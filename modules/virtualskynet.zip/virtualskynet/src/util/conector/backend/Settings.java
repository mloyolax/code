
package util.conector.backend;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for settings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="settings">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="monitorkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pbxip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordings" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="serviceip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenant" type="{http://ws.api/}tenant" minOccurs="0"/>
 *         &lt;element name="voicemailkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="whisperkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "settings", propOrder = {
    "id",
    "monitorkey",
    "pbxip",
    "recordings",
    "serviceip",
    "tenant",
    "voicemailkey",
    "whisperkey"
})
public class Settings {

    protected Integer id;
    protected String monitorkey;
    protected String pbxip;
    protected boolean recordings;
    protected String serviceip;
    protected Tenant tenant;
    protected String voicemailkey;
    protected String whisperkey;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the monitorkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonitorkey() {
        return monitorkey;
    }

    /**
     * Sets the value of the monitorkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonitorkey(String value) {
        this.monitorkey = value;
    }

    /**
     * Gets the value of the pbxip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPbxip() {
        return pbxip;
    }

    /**
     * Sets the value of the pbxip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPbxip(String value) {
        this.pbxip = value;
    }

    /**
     * Gets the value of the recordings property.
     * 
     */
    public boolean isRecordings() {
        return recordings;
    }

    /**
     * Sets the value of the recordings property.
     * 
     */
    public void setRecordings(boolean value) {
        this.recordings = value;
    }

    /**
     * Gets the value of the serviceip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceip() {
        return serviceip;
    }

    /**
     * Sets the value of the serviceip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceip(String value) {
        this.serviceip = value;
    }

    /**
     * Gets the value of the tenant property.
     * 
     * @return
     *     possible object is
     *     {@link Tenant }
     *     
     */
    public Tenant getTenant() {
        return tenant;
    }

    /**
     * Sets the value of the tenant property.
     * 
     * @param value
     *     allowed object is
     *     {@link Tenant }
     *     
     */
    public void setTenant(Tenant value) {
        this.tenant = value;
    }

    /**
     * Gets the value of the voicemailkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoicemailkey() {
        return voicemailkey;
    }

    /**
     * Sets the value of the voicemailkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoicemailkey(String value) {
        this.voicemailkey = value;
    }

    /**
     * Gets the value of the whisperkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWhisperkey() {
        return whisperkey;
    }

    /**
     * Sets the value of the whisperkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWhisperkey(String value) {
        this.whisperkey = value;
    }

}
