
package util.conector.backend;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for queueReportTotal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="queueReportTotal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="promna" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promns" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="promtmo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="sumabandon" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="sumconnect" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="sumenterqueue" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queueReportTotal", propOrder = {
    "promna",
    "promns",
    "promtmo",
    "sumabandon",
    "sumconnect",
    "sumenterqueue"
})
public class QueueReportTotal {

    protected int promna;
    protected int promns;
    protected int promtmo;
    protected int sumabandon;
    protected int sumconnect;
    protected int sumenterqueue;

    /**
     * Gets the value of the promna property.
     * 
     */
    public int getPromna() {
        return promna;
    }

    /**
     * Sets the value of the promna property.
     * 
     */
    public void setPromna(int value) {
        this.promna = value;
    }

    /**
     * Gets the value of the promns property.
     * 
     */
    public int getPromns() {
        return promns;
    }

    /**
     * Sets the value of the promns property.
     * 
     */
    public void setPromns(int value) {
        this.promns = value;
    }

    /**
     * Gets the value of the promtmo property.
     * 
     */
    public int getPromtmo() {
        return promtmo;
    }

    /**
     * Sets the value of the promtmo property.
     * 
     */
    public void setPromtmo(int value) {
        this.promtmo = value;
    }

    /**
     * Gets the value of the sumabandon property.
     * 
     */
    public int getSumabandon() {
        return sumabandon;
    }

    /**
     * Sets the value of the sumabandon property.
     * 
     */
    public void setSumabandon(int value) {
        this.sumabandon = value;
    }

    /**
     * Gets the value of the sumconnect property.
     * 
     */
    public int getSumconnect() {
        return sumconnect;
    }

    /**
     * Sets the value of the sumconnect property.
     * 
     */
    public void setSumconnect(int value) {
        this.sumconnect = value;
    }

    /**
     * Gets the value of the sumenterqueue property.
     * 
     */
    public int getSumenterqueue() {
        return sumenterqueue;
    }

    /**
     * Sets the value of the sumenterqueue property.
     * 
     */
    public void setSumenterqueue(int value) {
        this.sumenterqueue = value;
    }

}
