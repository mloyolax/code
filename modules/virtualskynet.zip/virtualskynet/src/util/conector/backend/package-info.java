@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.api/")
package util.conector.backend;
