
package util.conector.backend;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for followme complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="followme">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="application" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="call_from_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="context" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="declinecall" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exten" type="{http://ws.api/}exten" minOccurs="0"/>
 *         &lt;element name="hold_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="music" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="musicclass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="musiconhold" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="norecording_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="options_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sorry_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status_prompt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="takecall" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "followme", propOrder = {
    "application",
    "callFromPrompt",
    "context",
    "declinecall",
    "exten",
    "holdPrompt",
    "id",
    "music",
    "musicclass",
    "musiconhold",
    "name",
    "norecordingPrompt",
    "optionsPrompt",
    "sorryPrompt",
    "statusPrompt",
    "takecall"
})
public class Followme {

    protected String application;
    @XmlElement(name = "call_from_prompt")
    protected String callFromPrompt;
    protected String context;
    protected String declinecall;
    protected Exten exten;
    @XmlElement(name = "hold_prompt")
    protected String holdPrompt;
    protected Integer id;
    protected String music;
    protected String musicclass;
    protected String musiconhold;
    protected String name;
    @XmlElement(name = "norecording_prompt")
    protected String norecordingPrompt;
    @XmlElement(name = "options_prompt")
    protected String optionsPrompt;
    @XmlElement(name = "sorry_prompt")
    protected String sorryPrompt;
    @XmlElement(name = "status_prompt")
    protected String statusPrompt;
    protected String takecall;

    /**
     * Gets the value of the application property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplication() {
        return application;
    }

    /**
     * Sets the value of the application property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplication(String value) {
        this.application = value;
    }

    /**
     * Gets the value of the callFromPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallFromPrompt() {
        return callFromPrompt;
    }

    /**
     * Sets the value of the callFromPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallFromPrompt(String value) {
        this.callFromPrompt = value;
    }

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContext(String value) {
        this.context = value;
    }

    /**
     * Gets the value of the declinecall property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclinecall() {
        return declinecall;
    }

    /**
     * Sets the value of the declinecall property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclinecall(String value) {
        this.declinecall = value;
    }

    /**
     * Gets the value of the exten property.
     * 
     * @return
     *     possible object is
     *     {@link Exten }
     *     
     */
    public Exten getExten() {
        return exten;
    }

    /**
     * Sets the value of the exten property.
     * 
     * @param value
     *     allowed object is
     *     {@link Exten }
     *     
     */
    public void setExten(Exten value) {
        this.exten = value;
    }

    /**
     * Gets the value of the holdPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldPrompt() {
        return holdPrompt;
    }

    /**
     * Sets the value of the holdPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldPrompt(String value) {
        this.holdPrompt = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the music property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMusic() {
        return music;
    }

    /**
     * Sets the value of the music property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMusic(String value) {
        this.music = value;
    }

    /**
     * Gets the value of the musicclass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMusicclass() {
        return musicclass;
    }

    /**
     * Sets the value of the musicclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMusicclass(String value) {
        this.musicclass = value;
    }

    /**
     * Gets the value of the musiconhold property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMusiconhold() {
        return musiconhold;
    }

    /**
     * Sets the value of the musiconhold property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMusiconhold(String value) {
        this.musiconhold = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the norecordingPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNorecordingPrompt() {
        return norecordingPrompt;
    }

    /**
     * Sets the value of the norecordingPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNorecordingPrompt(String value) {
        this.norecordingPrompt = value;
    }

    /**
     * Gets the value of the optionsPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOptionsPrompt() {
        return optionsPrompt;
    }

    /**
     * Sets the value of the optionsPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOptionsPrompt(String value) {
        this.optionsPrompt = value;
    }

    /**
     * Gets the value of the sorryPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSorryPrompt() {
        return sorryPrompt;
    }

    /**
     * Sets the value of the sorryPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSorryPrompt(String value) {
        this.sorryPrompt = value;
    }

    /**
     * Gets the value of the statusPrompt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusPrompt() {
        return statusPrompt;
    }

    /**
     * Sets the value of the statusPrompt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusPrompt(String value) {
        this.statusPrompt = value;
    }

    /**
     * Gets the value of the takecall property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTakecall() {
        return takecall;
    }

    /**
     * Sets the value of the takecall property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTakecall(String value) {
        this.takecall = value;
    }

}
