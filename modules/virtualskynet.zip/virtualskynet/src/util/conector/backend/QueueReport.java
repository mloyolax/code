
package util.conector.backend;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for queueReport complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="queueReport">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="abandon" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="connect" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dateRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enterqueue" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="na" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ns" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="queuename" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tmo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queueReport", propOrder = {
    "abandon",
    "connect",
    "dateRange",
    "enterqueue",
    "na",
    "ns",
    "queuename",
    "tmo"
})
public class QueueReport {

    protected int abandon;
    protected int connect;
    protected String dateRange;
    protected int enterqueue;
    protected int na;
    protected int ns;
    protected String queuename;
    protected int tmo;

    /**
     * Gets the value of the abandon property.
     * 
     */
    public int getAbandon() {
        return abandon;
    }

    /**
     * Sets the value of the abandon property.
     * 
     */
    public void setAbandon(int value) {
        this.abandon = value;
    }

    /**
     * Gets the value of the connect property.
     * 
     */
    public int getConnect() {
        return connect;
    }

    /**
     * Sets the value of the connect property.
     * 
     */
    public void setConnect(int value) {
        this.connect = value;
    }

    /**
     * Gets the value of the dateRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateRange() {
        return dateRange;
    }

    /**
     * Sets the value of the dateRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateRange(String value) {
        this.dateRange = value;
    }

    /**
     * Gets the value of the enterqueue property.
     * 
     */
    public int getEnterqueue() {
        return enterqueue;
    }

    /**
     * Sets the value of the enterqueue property.
     * 
     */
    public void setEnterqueue(int value) {
        this.enterqueue = value;
    }

    /**
     * Gets the value of the na property.
     * 
     */
    public int getNa() {
        return na;
    }

    /**
     * Sets the value of the na property.
     * 
     */
    public void setNa(int value) {
        this.na = value;
    }

    /**
     * Gets the value of the ns property.
     * 
     */
    public int getNs() {
        return ns;
    }

    /**
     * Sets the value of the ns property.
     * 
     */
    public void setNs(int value) {
        this.ns = value;
    }

    /**
     * Gets the value of the queuename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueuename() {
        return queuename;
    }

    /**
     * Sets the value of the queuename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueuename(String value) {
        this.queuename = value;
    }

    /**
     * Gets the value of the tmo property.
     * 
     */
    public int getTmo() {
        return tmo;
    }

    /**
     * Sets the value of the tmo property.
     * 
     */
    public void setTmo(int value) {
        this.tmo = value;
    }

}
