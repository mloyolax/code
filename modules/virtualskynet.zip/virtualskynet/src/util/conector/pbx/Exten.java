
package util.conector.pbx;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for exten complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="exten">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountcode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountprofile" type="{http://ws.api/}accountProfile" minOccurs="0"/>
 *         &lt;element name="callbackextension" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="context" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="defaultuser" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="folowmes" type="{http://ws.api/}followMe" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="fullcontact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="host" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ipaddr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastms" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="port" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="regseconds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requirecalltoken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secret" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenantprofile" type="{http://ws.api/}tenantProfile" minOccurs="0"/>
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="useragent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="voicemail" type="{http://ws.api/}voicemail" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "exten", propOrder = {
    "accountcode",
    "accountprofile",
    "callbackextension",
    "callerId",
    "context",
    "defaultuser",
    "enabled",
    "folowmes",
    "fullcontact",
    "host",
    "id",
    "ipaddr",
    "lastms",
    "name",
    "port",
    "regseconds",
    "requirecalltoken",
    "secret",
    "tenantprofile",
    "type",
    "useragent",
    "voicemail"
})
public class Exten {

    protected String accountcode;
    protected AccountProfile accountprofile;
    protected String callbackextension;
    protected String callerId;
    protected String context;
    protected String defaultuser;
    protected Boolean enabled;
    @XmlElement(nillable = true)
    protected List<FollowMe> folowmes;
    protected String fullcontact;
    protected String host;
    protected Integer id;
    protected String ipaddr;
    protected String lastms;
    protected String name;
    protected String port;
    protected String regseconds;
    protected String requirecalltoken;
    protected String secret;
    protected TenantProfile tenantprofile;
    protected String type;
    protected String useragent;
    protected Voicemail voicemail;

    /**
     * Gets the value of the accountcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountcode() {
        return accountcode;
    }

    /**
     * Sets the value of the accountcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountcode(String value) {
        this.accountcode = value;
    }

    /**
     * Gets the value of the accountprofile property.
     * 
     * @return
     *     possible object is
     *     {@link AccountProfile }
     *     
     */
    public AccountProfile getAccountprofile() {
        return accountprofile;
    }

    /**
     * Sets the value of the accountprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountProfile }
     *     
     */
    public void setAccountprofile(AccountProfile value) {
        this.accountprofile = value;
    }

    /**
     * Gets the value of the callbackextension property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallbackextension() {
        return callbackextension;
    }

    /**
     * Sets the value of the callbackextension property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallbackextension(String value) {
        this.callbackextension = value;
    }

    /**
     * Gets the value of the callerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallerId() {
        return callerId;
    }

    /**
     * Sets the value of the callerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallerId(String value) {
        this.callerId = value;
    }

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContext(String value) {
        this.context = value;
    }

    /**
     * Gets the value of the defaultuser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultuser() {
        return defaultuser;
    }

    /**
     * Sets the value of the defaultuser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultuser(String value) {
        this.defaultuser = value;
    }

    /**
     * Gets the value of the enabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEnabled() {
        return enabled;
    }

    /**
     * Sets the value of the enabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEnabled(Boolean value) {
        this.enabled = value;
    }

    /**
     * Gets the value of the folowmes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the folowmes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFolowmes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FollowMe }
     * 
     * 
     */
    public List<FollowMe> getFolowmes() {
        if (folowmes == null) {
            folowmes = new ArrayList<FollowMe>();
        }
        return this.folowmes;
    }

    /**
     * Gets the value of the fullcontact property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFullcontact() {
        return fullcontact;
    }

    /**
     * Sets the value of the fullcontact property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFullcontact(String value) {
        this.fullcontact = value;
    }

    /**
     * Gets the value of the host property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHost() {
        return host;
    }

    /**
     * Sets the value of the host property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHost(String value) {
        this.host = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the ipaddr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIpaddr() {
        return ipaddr;
    }

    /**
     * Sets the value of the ipaddr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIpaddr(String value) {
        this.ipaddr = value;
    }

    /**
     * Gets the value of the lastms property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastms() {
        return lastms;
    }

    /**
     * Sets the value of the lastms property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastms(String value) {
        this.lastms = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the port property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPort() {
        return port;
    }

    /**
     * Sets the value of the port property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPort(String value) {
        this.port = value;
    }

    /**
     * Gets the value of the regseconds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegseconds() {
        return regseconds;
    }

    /**
     * Sets the value of the regseconds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegseconds(String value) {
        this.regseconds = value;
    }

    /**
     * Gets the value of the requirecalltoken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequirecalltoken() {
        return requirecalltoken;
    }

    /**
     * Sets the value of the requirecalltoken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequirecalltoken(String value) {
        this.requirecalltoken = value;
    }

    /**
     * Gets the value of the secret property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecret() {
        return secret;
    }

    /**
     * Sets the value of the secret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecret(String value) {
        this.secret = value;
    }

    /**
     * Gets the value of the tenantprofile property.
     * 
     * @return
     *     possible object is
     *     {@link TenantProfile }
     *     
     */
    public TenantProfile getTenantprofile() {
        return tenantprofile;
    }

    /**
     * Sets the value of the tenantprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenantProfile }
     *     
     */
    public void setTenantprofile(TenantProfile value) {
        this.tenantprofile = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the useragent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseragent() {
        return useragent;
    }

    /**
     * Sets the value of the useragent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseragent(String value) {
        this.useragent = value;
    }

    /**
     * Gets the value of the voicemail property.
     * 
     * @return
     *     possible object is
     *     {@link Voicemail }
     *     
     */
    public Voicemail getVoicemail() {
        return voicemail;
    }

    /**
     * Sets the value of the voicemail property.
     * 
     * @param value
     *     allowed object is
     *     {@link Voicemail }
     *     
     */
    public void setVoicemail(Voicemail value) {
        this.voicemail = value;
    }

}
