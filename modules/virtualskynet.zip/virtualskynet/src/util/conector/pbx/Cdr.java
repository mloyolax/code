
package util.conector.pbx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cdr complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="cdr">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountcode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountprofile" type="{http://ws.api/}accountProfile" minOccurs="0"/>
 *         &lt;element name="amaflags" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billsec" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="calldate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="channel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="clid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dcontext" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="disposition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dstchannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="duration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="lastapp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastdata" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="src" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenantprofile" type="{http://ws.api/}tenantProfile" minOccurs="0"/>
 *         &lt;element name="uniqueid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userfield" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cdr", propOrder = {
    "accountcode",
    "accountprofile",
    "amaflags",
    "billsec",
    "calldate",
    "channel",
    "clid",
    "dcontext",
    "disposition",
    "dst",
    "dstchannel",
    "duration",
    "id",
    "lastapp",
    "lastdata",
    "src",
    "tenantprofile",
    "uniqueid",
    "userfield"
})
public class Cdr {

    protected String accountcode;
    protected AccountProfile accountprofile;
    protected String amaflags;
    protected Integer billsec;
    protected String calldate;
    protected String channel;
    protected String clid;
    protected String dcontext;
    protected String disposition;
    protected String dst;
    protected String dstchannel;
    protected String duration;
    protected Integer id;
    protected String lastapp;
    protected String lastdata;
    protected String src;
    protected TenantProfile tenantprofile;
    protected String uniqueid;
    protected String userfield;

    /**
     * Gets the value of the accountcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountcode() {
        return accountcode;
    }

    /**
     * Sets the value of the accountcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountcode(String value) {
        this.accountcode = value;
    }

    /**
     * Gets the value of the accountprofile property.
     * 
     * @return
     *     possible object is
     *     {@link AccountProfile }
     *     
     */
    public AccountProfile getAccountprofile() {
        return accountprofile;
    }

    /**
     * Sets the value of the accountprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountProfile }
     *     
     */
    public void setAccountprofile(AccountProfile value) {
        this.accountprofile = value;
    }

    /**
     * Gets the value of the amaflags property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmaflags() {
        return amaflags;
    }

    /**
     * Sets the value of the amaflags property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmaflags(String value) {
        this.amaflags = value;
    }

    /**
     * Gets the value of the billsec property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBillsec() {
        return billsec;
    }

    /**
     * Sets the value of the billsec property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBillsec(Integer value) {
        this.billsec = value;
    }

    /**
     * Gets the value of the calldate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalldate() {
        return calldate;
    }

    /**
     * Sets the value of the calldate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalldate(String value) {
        this.calldate = value;
    }

    /**
     * Gets the value of the channel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Sets the value of the channel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Gets the value of the clid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClid() {
        return clid;
    }

    /**
     * Sets the value of the clid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClid(String value) {
        this.clid = value;
    }

    /**
     * Gets the value of the dcontext property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcontext() {
        return dcontext;
    }

    /**
     * Sets the value of the dcontext property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcontext(String value) {
        this.dcontext = value;
    }

    /**
     * Gets the value of the disposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisposition() {
        return disposition;
    }

    /**
     * Sets the value of the disposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisposition(String value) {
        this.disposition = value;
    }

    /**
     * Gets the value of the dst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDst() {
        return dst;
    }

    /**
     * Sets the value of the dst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDst(String value) {
        this.dst = value;
    }

    /**
     * Gets the value of the dstchannel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDstchannel() {
        return dstchannel;
    }

    /**
     * Sets the value of the dstchannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDstchannel(String value) {
        this.dstchannel = value;
    }

    /**
     * Gets the value of the duration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the value of the duration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the lastapp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastapp() {
        return lastapp;
    }

    /**
     * Sets the value of the lastapp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastapp(String value) {
        this.lastapp = value;
    }

    /**
     * Gets the value of the lastdata property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastdata() {
        return lastdata;
    }

    /**
     * Sets the value of the lastdata property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastdata(String value) {
        this.lastdata = value;
    }

    /**
     * Gets the value of the src property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrc() {
        return src;
    }

    /**
     * Sets the value of the src property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrc(String value) {
        this.src = value;
    }

    /**
     * Gets the value of the tenantprofile property.
     * 
     * @return
     *     possible object is
     *     {@link TenantProfile }
     *     
     */
    public TenantProfile getTenantprofile() {
        return tenantprofile;
    }

    /**
     * Sets the value of the tenantprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenantProfile }
     *     
     */
    public void setTenantprofile(TenantProfile value) {
        this.tenantprofile = value;
    }

    /**
     * Gets the value of the uniqueid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueid() {
        return uniqueid;
    }

    /**
     * Sets the value of the uniqueid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueid(String value) {
        this.uniqueid = value;
    }

    /**
     * Gets the value of the userfield property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserfield() {
        return userfield;
    }

    /**
     * Sets the value of the userfield property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserfield(String value) {
        this.userfield = value;
    }

}
