
package util.conector.pbx;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tenantProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tenantProfile">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="blacklist" type="{http://ws.api/}blacklist" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="cdrs" type="{http://ws.api/}cdr" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="conferences" type="{http://ws.api/}conference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="dialextensions" type="{http://ws.api/}dialExtension" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="extens" type="{http://ws.api/}exten" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="inboundroutes" type="{http://ws.api/}inboundRoute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ivrs" type="{http://ws.api/}ivr" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="musiconhold" type="{http://ws.api/}musicOnHold" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="outboundroutes" type="{http://ws.api/}outboundRoute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pitch" type="{http://ws.api/}pitch" minOccurs="0"/>
 *         &lt;element name="queues" type="{http://ws.api/}queue" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="recording" type="{http://ws.api/}recording" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="settings" type="{http://ws.api/}settings" minOccurs="0"/>
 *         &lt;element name="tenantId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="trunks" type="{http://ws.api/}trunk" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tenantProfile", propOrder = {
    "blacklist",
    "cdrs",
    "conferences",
    "dialextensions",
    "extens",
    "id",
    "inboundroutes",
    "ivrs",
    "musiconhold",
    "outboundroutes",
    "pitch",
    "queues",
    "recording",
    "settings",
    "tenantId",
    "trunks"
})
public class TenantProfile {

    @XmlElement(nillable = true)
    protected List<Blacklist> blacklist;
    @XmlElement(nillable = true)
    protected List<Cdr> cdrs;
    @XmlElement(nillable = true)
    protected List<Conference> conferences;
    @XmlElement(nillable = true)
    protected List<DialExtension> dialextensions;
    @XmlElement(nillable = true)
    protected List<Exten> extens;
    protected Integer id;
    @XmlElement(nillable = true)
    protected List<InboundRoute> inboundroutes;
    @XmlElement(nillable = true)
    protected List<Ivr> ivrs;
    @XmlElement(nillable = true)
    protected List<MusicOnHold> musiconhold;
    @XmlElement(nillable = true)
    protected List<OutboundRoute> outboundroutes;
    protected Pitch pitch;
    @XmlElement(nillable = true)
    protected List<Queue> queues;
    @XmlElement(nillable = true)
    protected List<Recording> recording;
    protected Settings settings;
    protected Integer tenantId;
    @XmlElement(nillable = true)
    protected List<Trunk> trunks;

    /**
     * Gets the value of the blacklist property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the blacklist property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBlacklist().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Blacklist }
     * 
     * 
     */
    public List<Blacklist> getBlacklist() {
        if (blacklist == null) {
            blacklist = new ArrayList<Blacklist>();
        }
        return this.blacklist;
    }

    /**
     * Gets the value of the cdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cdr }
     * 
     * 
     */
    public List<Cdr> getCdrs() {
        if (cdrs == null) {
            cdrs = new ArrayList<Cdr>();
        }
        return this.cdrs;
    }

    /**
     * Gets the value of the conferences property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the conferences property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConferences().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Conference }
     * 
     * 
     */
    public List<Conference> getConferences() {
        if (conferences == null) {
            conferences = new ArrayList<Conference>();
        }
        return this.conferences;
    }

    /**
     * Gets the value of the dialextensions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dialextensions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDialextensions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DialExtension }
     * 
     * 
     */
    public List<DialExtension> getDialextensions() {
        if (dialextensions == null) {
            dialextensions = new ArrayList<DialExtension>();
        }
        return this.dialextensions;
    }

    /**
     * Gets the value of the extens property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extens property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtens().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Exten }
     * 
     * 
     */
    public List<Exten> getExtens() {
        if (extens == null) {
            extens = new ArrayList<Exten>();
        }
        return this.extens;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the inboundroutes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inboundroutes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInboundroutes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InboundRoute }
     * 
     * 
     */
    public List<InboundRoute> getInboundroutes() {
        if (inboundroutes == null) {
            inboundroutes = new ArrayList<InboundRoute>();
        }
        return this.inboundroutes;
    }

    /**
     * Gets the value of the ivrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ivrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIvrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Ivr }
     * 
     * 
     */
    public List<Ivr> getIvrs() {
        if (ivrs == null) {
            ivrs = new ArrayList<Ivr>();
        }
        return this.ivrs;
    }

    /**
     * Gets the value of the musiconhold property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the musiconhold property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMusiconhold().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MusicOnHold }
     * 
     * 
     */
    public List<MusicOnHold> getMusiconhold() {
        if (musiconhold == null) {
            musiconhold = new ArrayList<MusicOnHold>();
        }
        return this.musiconhold;
    }

    /**
     * Gets the value of the outboundroutes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outboundroutes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutboundroutes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OutboundRoute }
     * 
     * 
     */
    public List<OutboundRoute> getOutboundroutes() {
        if (outboundroutes == null) {
            outboundroutes = new ArrayList<OutboundRoute>();
        }
        return this.outboundroutes;
    }

    /**
     * Gets the value of the pitch property.
     * 
     * @return
     *     possible object is
     *     {@link Pitch }
     *     
     */
    public Pitch getPitch() {
        return pitch;
    }

    /**
     * Sets the value of the pitch property.
     * 
     * @param value
     *     allowed object is
     *     {@link Pitch }
     *     
     */
    public void setPitch(Pitch value) {
        this.pitch = value;
    }

    /**
     * Gets the value of the queues property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the queues property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQueues().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Queue }
     * 
     * 
     */
    public List<Queue> getQueues() {
        if (queues == null) {
            queues = new ArrayList<Queue>();
        }
        return this.queues;
    }

    /**
     * Gets the value of the recording property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the recording property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecording().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Recording }
     * 
     * 
     */
    public List<Recording> getRecording() {
        if (recording == null) {
            recording = new ArrayList<Recording>();
        }
        return this.recording;
    }

    /**
     * Gets the value of the settings property.
     * 
     * @return
     *     possible object is
     *     {@link Settings }
     *     
     */
    public Settings getSettings() {
        return settings;
    }

    /**
     * Sets the value of the settings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Settings }
     *     
     */
    public void setSettings(Settings value) {
        this.settings = value;
    }

    /**
     * Gets the value of the tenantId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTenantId() {
        return tenantId;
    }

    /**
     * Sets the value of the tenantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTenantId(Integer value) {
        this.tenantId = value;
    }

    /**
     * Gets the value of the trunks property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trunks property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrunks().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Trunk }
     * 
     * 
     */
    public List<Trunk> getTrunks() {
        if (trunks == null) {
            trunks = new ArrayList<Trunk>();
        }
        return this.trunks;
    }

}
