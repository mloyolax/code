
package util.conector.pbx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for queueMember complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="queueMember">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountprofile" type="{http://ws.api/}accountProfile" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="interfaceI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="membername" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paused" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="penalty" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="queue" type="{http://ws.api/}queue" minOccurs="0"/>
 *         &lt;element name="queue_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="uniqueid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queueMember", propOrder = {
    "accountprofile",
    "id",
    "interfaceI",
    "membername",
    "paused",
    "penalty",
    "queue",
    "queueName",
    "uniqueid"
})
public class QueueMember {

    protected AccountProfile accountprofile;
    protected Integer id;
    protected String interfaceI;
    protected String membername;
    protected String paused;
    protected String penalty;
    protected Queue queue;
    @XmlElement(name = "queue_name")
    protected String queueName;
    protected String uniqueid;

    /**
     * Gets the value of the accountprofile property.
     * 
     * @return
     *     possible object is
     *     {@link AccountProfile }
     *     
     */
    public AccountProfile getAccountprofile() {
        return accountprofile;
    }

    /**
     * Sets the value of the accountprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountProfile }
     *     
     */
    public void setAccountprofile(AccountProfile value) {
        this.accountprofile = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the interfaceI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterfaceI() {
        return interfaceI;
    }

    /**
     * Sets the value of the interfaceI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterfaceI(String value) {
        this.interfaceI = value;
    }

    /**
     * Gets the value of the membername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMembername() {
        return membername;
    }

    /**
     * Sets the value of the membername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMembername(String value) {
        this.membername = value;
    }

    /**
     * Gets the value of the paused property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaused() {
        return paused;
    }

    /**
     * Sets the value of the paused property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaused(String value) {
        this.paused = value;
    }

    /**
     * Gets the value of the penalty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenalty() {
        return penalty;
    }

    /**
     * Sets the value of the penalty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenalty(String value) {
        this.penalty = value;
    }

    /**
     * Gets the value of the queue property.
     * 
     * @return
     *     possible object is
     *     {@link Queue }
     *     
     */
    public Queue getQueue() {
        return queue;
    }

    /**
     * Sets the value of the queue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Queue }
     *     
     */
    public void setQueue(Queue value) {
        this.queue = value;
    }

    /**
     * Gets the value of the queueName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueueName() {
        return queueName;
    }

    /**
     * Sets the value of the queueName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueueName(String value) {
        this.queueName = value;
    }

    /**
     * Gets the value of the uniqueid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueid() {
        return uniqueid;
    }

    /**
     * Sets the value of the uniqueid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueid(String value) {
        this.uniqueid = value;
    }

}
