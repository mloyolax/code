
package util.conector.pbx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for conference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="conference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="adminopts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="adminpin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bookid" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="confno" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="endtime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="maxusers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="members" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="opts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordingfilename" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recordingformat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="starttime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenantprofile" type="{http://ws.api/}tenantProfile" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "conference", propOrder = {
    "adminopts",
    "adminpin",
    "bookid",
    "confno",
    "description",
    "endtime",
    "id",
    "maxusers",
    "members",
    "opts",
    "pin",
    "recordingfilename",
    "recordingformat",
    "starttime",
    "tenantprofile"
})
public class Conference {

    protected String adminopts;
    protected String adminpin;
    protected Integer bookid;
    protected String confno;
    protected String description;
    protected String endtime;
    protected Integer id;
    protected String maxusers;
    protected String members;
    protected String opts;
    protected String pin;
    protected String recordingfilename;
    protected String recordingformat;
    protected String starttime;
    protected TenantProfile tenantprofile;

    /**
     * Gets the value of the adminopts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdminopts() {
        return adminopts;
    }

    /**
     * Sets the value of the adminopts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdminopts(String value) {
        this.adminopts = value;
    }

    /**
     * Gets the value of the adminpin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdminpin() {
        return adminpin;
    }

    /**
     * Sets the value of the adminpin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdminpin(String value) {
        this.adminpin = value;
    }

    /**
     * Gets the value of the bookid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBookid() {
        return bookid;
    }

    /**
     * Sets the value of the bookid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBookid(Integer value) {
        this.bookid = value;
    }

    /**
     * Gets the value of the confno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfno() {
        return confno;
    }

    /**
     * Sets the value of the confno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfno(String value) {
        this.confno = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the endtime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndtime() {
        return endtime;
    }

    /**
     * Sets the value of the endtime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndtime(String value) {
        this.endtime = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the maxusers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxusers() {
        return maxusers;
    }

    /**
     * Sets the value of the maxusers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxusers(String value) {
        this.maxusers = value;
    }

    /**
     * Gets the value of the members property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMembers() {
        return members;
    }

    /**
     * Sets the value of the members property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMembers(String value) {
        this.members = value;
    }

    /**
     * Gets the value of the opts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpts() {
        return opts;
    }

    /**
     * Sets the value of the opts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpts(String value) {
        this.opts = value;
    }

    /**
     * Gets the value of the pin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPin() {
        return pin;
    }

    /**
     * Sets the value of the pin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPin(String value) {
        this.pin = value;
    }

    /**
     * Gets the value of the recordingfilename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordingfilename() {
        return recordingfilename;
    }

    /**
     * Sets the value of the recordingfilename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordingfilename(String value) {
        this.recordingfilename = value;
    }

    /**
     * Gets the value of the recordingformat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordingformat() {
        return recordingformat;
    }

    /**
     * Sets the value of the recordingformat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordingformat(String value) {
        this.recordingformat = value;
    }

    /**
     * Gets the value of the starttime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStarttime() {
        return starttime;
    }

    /**
     * Sets the value of the starttime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStarttime(String value) {
        this.starttime = value;
    }

    /**
     * Gets the value of the tenantprofile property.
     * 
     * @return
     *     possible object is
     *     {@link TenantProfile }
     *     
     */
    public TenantProfile getTenantprofile() {
        return tenantprofile;
    }

    /**
     * Sets the value of the tenantprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenantProfile }
     *     
     */
    public void setTenantprofile(TenantProfile value) {
        this.tenantprofile = value;
    }

}
