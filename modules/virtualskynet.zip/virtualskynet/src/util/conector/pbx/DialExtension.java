
package util.conector.pbx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for dialExtension complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="dialExtension">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="app" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appdata" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="context" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exten" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="tenantprofile" type="{http://ws.api/}tenantProfile" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "dialExtension", propOrder = {
    "app",
    "appdata",
    "context",
    "exten",
    "id",
    "priority",
    "tenantprofile"
})
public class DialExtension {

    protected String app;
    protected String appdata;
    protected String context;
    protected String exten;
    protected Integer id;
    protected Integer priority;
    protected TenantProfile tenantprofile;

    /**
     * Gets the value of the app property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApp() {
        return app;
    }

    /**
     * Sets the value of the app property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApp(String value) {
        this.app = value;
    }

    /**
     * Gets the value of the appdata property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppdata() {
        return appdata;
    }

    /**
     * Sets the value of the appdata property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppdata(String value) {
        this.appdata = value;
    }

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContext(String value) {
        this.context = value;
    }

    /**
     * Gets the value of the exten property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExten() {
        return exten;
    }

    /**
     * Sets the value of the exten property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExten(String value) {
        this.exten = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPriority(Integer value) {
        this.priority = value;
    }

    /**
     * Gets the value of the tenantprofile property.
     * 
     * @return
     *     possible object is
     *     {@link TenantProfile }
     *     
     */
    public TenantProfile getTenantprofile() {
        return tenantprofile;
    }

    /**
     * Sets the value of the tenantprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenantProfile }
     *     
     */
    public void setTenantprofile(TenantProfile value) {
        this.tenantprofile = value;
    }

}
