
package util.conector.pbx;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for trunk complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="trunk">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="addprefix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="creation" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="hostname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outboundroute" type="{http://ws.api/}outboundRoute" minOccurs="0"/>
 *         &lt;element name="outboundroutes" type="{http://ws.api/}outboundRoute" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="password" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="removeprefix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tech" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenantprofile" type="{http://ws.api/}tenantProfile" minOccurs="0"/>
 *         &lt;element name="timeout" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="username" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "trunk", propOrder = {
    "addprefix",
    "creation",
    "hostname",
    "id",
    "name",
    "outboundroute",
    "outboundroutes",
    "password",
    "removeprefix",
    "tech",
    "tenantprofile",
    "timeout",
    "username"
})
public class Trunk {

    protected String addprefix;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar creation;
    protected String hostname;
    protected Integer id;
    protected String name;
    protected OutboundRoute outboundroute;
    @XmlElement(nillable = true)
    protected List<OutboundRoute> outboundroutes;
    protected String password;
    protected String removeprefix;
    protected String tech;
    protected TenantProfile tenantprofile;
    protected String timeout;
    protected String username;

    /**
     * Gets the value of the addprefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddprefix() {
        return addprefix;
    }

    /**
     * Sets the value of the addprefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddprefix(String value) {
        this.addprefix = value;
    }

    /**
     * Gets the value of the creation property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreation() {
        return creation;
    }

    /**
     * Sets the value of the creation property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreation(XMLGregorianCalendar value) {
        this.creation = value;
    }

    /**
     * Gets the value of the hostname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostname() {
        return hostname;
    }

    /**
     * Sets the value of the hostname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostname(String value) {
        this.hostname = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the outboundroute property.
     * 
     * @return
     *     possible object is
     *     {@link OutboundRoute }
     *     
     */
    public OutboundRoute getOutboundroute() {
        return outboundroute;
    }

    /**
     * Sets the value of the outboundroute property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutboundRoute }
     *     
     */
    public void setOutboundroute(OutboundRoute value) {
        this.outboundroute = value;
    }

    /**
     * Gets the value of the outboundroutes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outboundroutes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutboundroutes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OutboundRoute }
     * 
     * 
     */
    public List<OutboundRoute> getOutboundroutes() {
        if (outboundroutes == null) {
            outboundroutes = new ArrayList<OutboundRoute>();
        }
        return this.outboundroutes;
    }

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }

    /**
     * Gets the value of the removeprefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemoveprefix() {
        return removeprefix;
    }

    /**
     * Sets the value of the removeprefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemoveprefix(String value) {
        this.removeprefix = value;
    }

    /**
     * Gets the value of the tech property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTech() {
        return tech;
    }

    /**
     * Sets the value of the tech property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTech(String value) {
        this.tech = value;
    }

    /**
     * Gets the value of the tenantprofile property.
     * 
     * @return
     *     possible object is
     *     {@link TenantProfile }
     *     
     */
    public TenantProfile getTenantprofile() {
        return tenantprofile;
    }

    /**
     * Sets the value of the tenantprofile property.
     * 
     * @param value
     *     allowed object is
     *     {@link TenantProfile }
     *     
     */
    public void setTenantprofile(TenantProfile value) {
        this.tenantprofile = value;
    }

    /**
     * Gets the value of the timeout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeout() {
        return timeout;
    }

    /**
     * Sets the value of the timeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeout(String value) {
        this.timeout = value;
    }

    /**
     * Gets the value of the username property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the value of the username property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsername(String value) {
        this.username = value;
    }

}
