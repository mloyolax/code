
package util.conector.pbx;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for extenVoicemail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="extenVoicemail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="attach" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="attachfmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="backupdeleted" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callback" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cidinternalcontexts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="context" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="delete" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dialout" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="envelope" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exitcontext" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exten" type="{http://ws.api/}exten" minOccurs="0"/>
 *         &lt;element name="forcegreetings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="forcename" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fullname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hidefromdir" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="listenccontrolcpausekey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listenccontrolcrestartkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listenccontrolcreversekey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listencontrolforwardkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listencontrolstopkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mailbox" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="messagewrap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="minpassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nextaftercmd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="operator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pager" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="review" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="saycid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sayduration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="saydurationm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="searchcontexts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sendvoicemail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tempgreetwarn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tz" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="uniqueid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmmismatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmnewpassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmpasschanged" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmpassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmplstryagain" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vmreenterpassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="volgain" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "extenVoicemail", propOrder = {
    "attach",
    "attachfmt",
    "backupdeleted",
    "callback",
    "cidinternalcontexts",
    "context",
    "delete",
    "dialout",
    "email",
    "envelope",
    "exitcontext",
    "exten",
    "forcegreetings",
    "forcename",
    "fullname",
    "hidefromdir",
    "id",
    "listenccontrolcpausekey",
    "listenccontrolcrestartkey",
    "listenccontrolcreversekey",
    "listencontrolforwardkey",
    "listencontrolstopkey",
    "mailbox",
    "messagewrap",
    "minpassword",
    "nextaftercmd",
    "operator",
    "pager",
    "review",
    "saycid",
    "sayduration",
    "saydurationm",
    "searchcontexts",
    "sendvoicemail",
    "stamp",
    "tempgreetwarn",
    "tz",
    "uniqueid",
    "vmmismatch",
    "vmnewpassword",
    "vmpasschanged",
    "vmpassword",
    "vmplstryagain",
    "vmreenterpassword",
    "volgain"
})
public class ExtenVoicemail {

    protected String attach;
    protected String attachfmt;
    protected String backupdeleted;
    protected String callback;
    protected String cidinternalcontexts;
    protected String context;
    protected String delete;
    protected String dialout;
    protected String email;
    protected String envelope;
    protected String exitcontext;
    protected Exten exten;
    protected String forcegreetings;
    protected String forcename;
    protected String fullname;
    protected String hidefromdir;
    protected Integer id;
    protected String listenccontrolcpausekey;
    protected String listenccontrolcrestartkey;
    protected String listenccontrolcreversekey;
    protected String listencontrolforwardkey;
    protected String listencontrolstopkey;
    protected String mailbox;
    protected String messagewrap;
    protected String minpassword;
    protected String nextaftercmd;
    protected String operator;
    protected String pager;
    protected String review;
    protected String saycid;
    protected String sayduration;
    protected String saydurationm;
    protected String searchcontexts;
    protected String sendvoicemail;
    protected String stamp;
    protected String tempgreetwarn;
    protected String tz;
    protected String uniqueid;
    protected String vmmismatch;
    protected String vmnewpassword;
    protected String vmpasschanged;
    protected String vmpassword;
    protected String vmplstryagain;
    protected String vmreenterpassword;
    protected String volgain;

    /**
     * Gets the value of the attach property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttach() {
        return attach;
    }

    /**
     * Sets the value of the attach property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttach(String value) {
        this.attach = value;
    }

    /**
     * Gets the value of the attachfmt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachfmt() {
        return attachfmt;
    }

    /**
     * Sets the value of the attachfmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachfmt(String value) {
        this.attachfmt = value;
    }

    /**
     * Gets the value of the backupdeleted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackupdeleted() {
        return backupdeleted;
    }

    /**
     * Sets the value of the backupdeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackupdeleted(String value) {
        this.backupdeleted = value;
    }

    /**
     * Gets the value of the callback property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallback() {
        return callback;
    }

    /**
     * Sets the value of the callback property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallback(String value) {
        this.callback = value;
    }

    /**
     * Gets the value of the cidinternalcontexts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCidinternalcontexts() {
        return cidinternalcontexts;
    }

    /**
     * Sets the value of the cidinternalcontexts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCidinternalcontexts(String value) {
        this.cidinternalcontexts = value;
    }

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContext(String value) {
        this.context = value;
    }

    /**
     * Gets the value of the delete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelete() {
        return delete;
    }

    /**
     * Sets the value of the delete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelete(String value) {
        this.delete = value;
    }

    /**
     * Gets the value of the dialout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDialout() {
        return dialout;
    }

    /**
     * Sets the value of the dialout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDialout(String value) {
        this.dialout = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the envelope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnvelope() {
        return envelope;
    }

    /**
     * Sets the value of the envelope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnvelope(String value) {
        this.envelope = value;
    }

    /**
     * Gets the value of the exitcontext property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExitcontext() {
        return exitcontext;
    }

    /**
     * Sets the value of the exitcontext property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExitcontext(String value) {
        this.exitcontext = value;
    }

    /**
     * Gets the value of the exten property.
     * 
     * @return
     *     possible object is
     *     {@link Exten }
     *     
     */
    public Exten getExten() {
        return exten;
    }

    /**
     * Sets the value of the exten property.
     * 
     * @param value
     *     allowed object is
     *     {@link Exten }
     *     
     */
    public void setExten(Exten value) {
        this.exten = value;
    }

    /**
     * Gets the value of the forcegreetings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForcegreetings() {
        return forcegreetings;
    }

    /**
     * Sets the value of the forcegreetings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForcegreetings(String value) {
        this.forcegreetings = value;
    }

    /**
     * Gets the value of the forcename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForcename() {
        return forcename;
    }

    /**
     * Sets the value of the forcename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForcename(String value) {
        this.forcename = value;
    }

    /**
     * Gets the value of the fullname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFullname() {
        return fullname;
    }

    /**
     * Sets the value of the fullname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFullname(String value) {
        this.fullname = value;
    }

    /**
     * Gets the value of the hidefromdir property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHidefromdir() {
        return hidefromdir;
    }

    /**
     * Sets the value of the hidefromdir property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHidefromdir(String value) {
        this.hidefromdir = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the listenccontrolcpausekey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenccontrolcpausekey() {
        return listenccontrolcpausekey;
    }

    /**
     * Sets the value of the listenccontrolcpausekey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenccontrolcpausekey(String value) {
        this.listenccontrolcpausekey = value;
    }

    /**
     * Gets the value of the listenccontrolcrestartkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenccontrolcrestartkey() {
        return listenccontrolcrestartkey;
    }

    /**
     * Sets the value of the listenccontrolcrestartkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenccontrolcrestartkey(String value) {
        this.listenccontrolcrestartkey = value;
    }

    /**
     * Gets the value of the listenccontrolcreversekey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListenccontrolcreversekey() {
        return listenccontrolcreversekey;
    }

    /**
     * Sets the value of the listenccontrolcreversekey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListenccontrolcreversekey(String value) {
        this.listenccontrolcreversekey = value;
    }

    /**
     * Gets the value of the listencontrolforwardkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListencontrolforwardkey() {
        return listencontrolforwardkey;
    }

    /**
     * Sets the value of the listencontrolforwardkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListencontrolforwardkey(String value) {
        this.listencontrolforwardkey = value;
    }

    /**
     * Gets the value of the listencontrolstopkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListencontrolstopkey() {
        return listencontrolstopkey;
    }

    /**
     * Sets the value of the listencontrolstopkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListencontrolstopkey(String value) {
        this.listencontrolstopkey = value;
    }

    /**
     * Gets the value of the mailbox property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailbox() {
        return mailbox;
    }

    /**
     * Sets the value of the mailbox property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailbox(String value) {
        this.mailbox = value;
    }

    /**
     * Gets the value of the messagewrap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessagewrap() {
        return messagewrap;
    }

    /**
     * Sets the value of the messagewrap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessagewrap(String value) {
        this.messagewrap = value;
    }

    /**
     * Gets the value of the minpassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinpassword() {
        return minpassword;
    }

    /**
     * Sets the value of the minpassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinpassword(String value) {
        this.minpassword = value;
    }

    /**
     * Gets the value of the nextaftercmd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextaftercmd() {
        return nextaftercmd;
    }

    /**
     * Sets the value of the nextaftercmd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextaftercmd(String value) {
        this.nextaftercmd = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperator(String value) {
        this.operator = value;
    }

    /**
     * Gets the value of the pager property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPager() {
        return pager;
    }

    /**
     * Sets the value of the pager property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPager(String value) {
        this.pager = value;
    }

    /**
     * Gets the value of the review property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReview() {
        return review;
    }

    /**
     * Sets the value of the review property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReview(String value) {
        this.review = value;
    }

    /**
     * Gets the value of the saycid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaycid() {
        return saycid;
    }

    /**
     * Sets the value of the saycid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaycid(String value) {
        this.saycid = value;
    }

    /**
     * Gets the value of the sayduration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSayduration() {
        return sayduration;
    }

    /**
     * Sets the value of the sayduration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSayduration(String value) {
        this.sayduration = value;
    }

    /**
     * Gets the value of the saydurationm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaydurationm() {
        return saydurationm;
    }

    /**
     * Sets the value of the saydurationm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaydurationm(String value) {
        this.saydurationm = value;
    }

    /**
     * Gets the value of the searchcontexts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchcontexts() {
        return searchcontexts;
    }

    /**
     * Sets the value of the searchcontexts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchcontexts(String value) {
        this.searchcontexts = value;
    }

    /**
     * Gets the value of the sendvoicemail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendvoicemail() {
        return sendvoicemail;
    }

    /**
     * Sets the value of the sendvoicemail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendvoicemail(String value) {
        this.sendvoicemail = value;
    }

    /**
     * Gets the value of the stamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStamp() {
        return stamp;
    }

    /**
     * Sets the value of the stamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStamp(String value) {
        this.stamp = value;
    }

    /**
     * Gets the value of the tempgreetwarn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTempgreetwarn() {
        return tempgreetwarn;
    }

    /**
     * Sets the value of the tempgreetwarn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTempgreetwarn(String value) {
        this.tempgreetwarn = value;
    }

    /**
     * Gets the value of the tz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTz() {
        return tz;
    }

    /**
     * Sets the value of the tz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTz(String value) {
        this.tz = value;
    }

    /**
     * Gets the value of the uniqueid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueid() {
        return uniqueid;
    }

    /**
     * Sets the value of the uniqueid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueid(String value) {
        this.uniqueid = value;
    }

    /**
     * Gets the value of the vmmismatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmmismatch() {
        return vmmismatch;
    }

    /**
     * Sets the value of the vmmismatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmmismatch(String value) {
        this.vmmismatch = value;
    }

    /**
     * Gets the value of the vmnewpassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmnewpassword() {
        return vmnewpassword;
    }

    /**
     * Sets the value of the vmnewpassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmnewpassword(String value) {
        this.vmnewpassword = value;
    }

    /**
     * Gets the value of the vmpasschanged property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmpasschanged() {
        return vmpasschanged;
    }

    /**
     * Sets the value of the vmpasschanged property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmpasschanged(String value) {
        this.vmpasschanged = value;
    }

    /**
     * Gets the value of the vmpassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmpassword() {
        return vmpassword;
    }

    /**
     * Sets the value of the vmpassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmpassword(String value) {
        this.vmpassword = value;
    }

    /**
     * Gets the value of the vmplstryagain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmplstryagain() {
        return vmplstryagain;
    }

    /**
     * Sets the value of the vmplstryagain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmplstryagain(String value) {
        this.vmplstryagain = value;
    }

    /**
     * Gets the value of the vmreenterpassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVmreenterpassword() {
        return vmreenterpassword;
    }

    /**
     * Sets the value of the vmreenterpassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVmreenterpassword(String value) {
        this.vmreenterpassword = value;
    }

    /**
     * Gets the value of the volgain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVolgain() {
        return volgain;
    }

    /**
     * Sets the value of the volgain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVolgain(String value) {
        this.volgain = value;
    }

}
