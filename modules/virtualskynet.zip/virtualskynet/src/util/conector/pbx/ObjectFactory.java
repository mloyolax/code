
package util.conector.pbx;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the util.conector.pbx package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OnDeleteTenant_QNAME = new QName("http://ws.api/", "onDeleteTenant");
    private final static QName _GetTenantProfileById_QNAME = new QName("http://ws.api/", "getTenantProfileById");
    private final static QName _GetTenantProfileByIdResponse_QNAME = new QName("http://ws.api/", "getTenantProfileByIdResponse");
    private final static QName _AddInboundRouteResponse_QNAME = new QName("http://ws.api/", "addInboundRouteResponse");
    private final static QName _DeleteQueuemembersByQueueResponse_QNAME = new QName("http://ws.api/", "deleteQueuemembersByQueueResponse");
    private final static QName _GetTrunkById_QNAME = new QName("http://ws.api/", "getTrunkById");
    private final static QName _UpdateQueueResponse_QNAME = new QName("http://ws.api/", "updateQueueResponse");
    private final static QName _UpdateInboundRoute_QNAME = new QName("http://ws.api/", "updateInboundRoute");
    private final static QName _ListInboundRoutesResponse_QNAME = new QName("http://ws.api/", "listInboundRoutesResponse");
    private final static QName _ListQueuesByTenant_QNAME = new QName("http://ws.api/", "listQueuesByTenant");
    private final static QName _GetExtenByAccountcodeResponse_QNAME = new QName("http://ws.api/", "getExtenByAccountcodeResponse");
    private final static QName _GetSettingsByTenant_QNAME = new QName("http://ws.api/", "getSettingsByTenant");
    private final static QName _ListCdrsByTenantResponse_QNAME = new QName("http://ws.api/", "listCdrsByTenantResponse");
    private final static QName _UpdateSettingsResponse_QNAME = new QName("http://ws.api/", "updateSettingsResponse");
    private final static QName _AddQueue_QNAME = new QName("http://ws.api/", "addQueue");
    private final static QName _ListTrunks_QNAME = new QName("http://ws.api/", "listTrunks");
    private final static QName _AddInboundRoute_QNAME = new QName("http://ws.api/", "addInboundRoute");
    private final static QName _UpdateInboundRouteResponse_QNAME = new QName("http://ws.api/", "updateInboundRouteResponse");
    private final static QName _UpdateExtenResponse_QNAME = new QName("http://ws.api/", "updateExtenResponse");
    private final static QName _OnDeleteTenantResponse_QNAME = new QName("http://ws.api/", "onDeleteTenantResponse");
    private final static QName _DeleteTrunkResponse_QNAME = new QName("http://ws.api/", "deleteTrunkResponse");
    private final static QName _DeleteQueueResponse_QNAME = new QName("http://ws.api/", "deleteQueueResponse");
    private final static QName _GetAccountProfileById_QNAME = new QName("http://ws.api/", "getAccountProfileById");
    private final static QName _UpdateSettings_QNAME = new QName("http://ws.api/", "updateSettings");
    private final static QName _AddQueuemember_QNAME = new QName("http://ws.api/", "addQueuemember");
    private final static QName _DeleteQueue_QNAME = new QName("http://ws.api/", "deleteQueue");
    private final static QName _OnDeleteAccountResponse_QNAME = new QName("http://ws.api/", "onDeleteAccountResponse");
    private final static QName _GetAccountProfileByIdResponse_QNAME = new QName("http://ws.api/", "getAccountProfileByIdResponse");
    private final static QName _DeleteTrunk_QNAME = new QName("http://ws.api/", "deleteTrunk");
    private final static QName _GetInboundRouteByIdResponse_QNAME = new QName("http://ws.api/", "getInboundRouteByIdResponse");
    private final static QName _UpdateExten_QNAME = new QName("http://ws.api/", "updateExten");
    private final static QName _AddQueueResponse_QNAME = new QName("http://ws.api/", "addQueueResponse");
    private final static QName _UpdateQueue_QNAME = new QName("http://ws.api/", "updateQueue");
    private final static QName _DeleteInboundRouteResponse_QNAME = new QName("http://ws.api/", "deleteInboundRouteResponse");
    private final static QName _AddExtenResponse_QNAME = new QName("http://ws.api/", "addExtenResponse");
    private final static QName _AddQueuememberResponse_QNAME = new QName("http://ws.api/", "addQueuememberResponse");
    private final static QName _AddExten_QNAME = new QName("http://ws.api/", "addExten");
    private final static QName _UpdateTrunk_QNAME = new QName("http://ws.api/", "updateTrunk");
    private final static QName _ListQueuesByTenantResponse_QNAME = new QName("http://ws.api/", "listQueuesByTenantResponse");
    private final static QName _DeleteQueuemembersByQueue_QNAME = new QName("http://ws.api/", "deleteQueuemembersByQueue");
    private final static QName _GetTrunkByIdResponse_QNAME = new QName("http://ws.api/", "getTrunkByIdResponse");
    private final static QName _GetExtenByAccountcode_QNAME = new QName("http://ws.api/", "getExtenByAccountcode");
    private final static QName _GetInboundRouteById_QNAME = new QName("http://ws.api/", "getInboundRouteById");
    private final static QName _GetSettingsByTenantResponse_QNAME = new QName("http://ws.api/", "getSettingsByTenantResponse");
    private final static QName _ListCdrsByTenant_QNAME = new QName("http://ws.api/", "listCdrsByTenant");
    private final static QName _ListInboundRoutes_QNAME = new QName("http://ws.api/", "listInboundRoutes");
    private final static QName _ListTrunksResponse_QNAME = new QName("http://ws.api/", "listTrunksResponse");
    private final static QName _OnDeleteAccount_QNAME = new QName("http://ws.api/", "onDeleteAccount");
    private final static QName _AddTrunkResponse_QNAME = new QName("http://ws.api/", "addTrunkResponse");
    private final static QName _DeleteInboundRoute_QNAME = new QName("http://ws.api/", "deleteInboundRoute");
    private final static QName _AddTrunk_QNAME = new QName("http://ws.api/", "addTrunk");
    private final static QName _UpdateTrunkResponse_QNAME = new QName("http://ws.api/", "updateTrunkResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: util.conector.pbx
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AddInboundRouteResponse }
     * 
     */
    public AddInboundRouteResponse createAddInboundRouteResponse() {
        return new AddInboundRouteResponse();
    }

    /**
     * Create an instance of {@link GetTenantProfileByIdResponse }
     * 
     */
    public GetTenantProfileByIdResponse createGetTenantProfileByIdResponse() {
        return new GetTenantProfileByIdResponse();
    }

    /**
     * Create an instance of {@link DeleteQueuemembersByQueueResponse }
     * 
     */
    public DeleteQueuemembersByQueueResponse createDeleteQueuemembersByQueueResponse() {
        return new DeleteQueuemembersByQueueResponse();
    }

    /**
     * Create an instance of {@link GetTenantProfileById }
     * 
     */
    public GetTenantProfileById createGetTenantProfileById() {
        return new GetTenantProfileById();
    }

    /**
     * Create an instance of {@link OnDeleteTenant }
     * 
     */
    public OnDeleteTenant createOnDeleteTenant() {
        return new OnDeleteTenant();
    }

    /**
     * Create an instance of {@link AddQueue }
     * 
     */
    public AddQueue createAddQueue() {
        return new AddQueue();
    }

    /**
     * Create an instance of {@link UpdateSettingsResponse }
     * 
     */
    public UpdateSettingsResponse createUpdateSettingsResponse() {
        return new UpdateSettingsResponse();
    }

    /**
     * Create an instance of {@link ListCdrsByTenantResponse }
     * 
     */
    public ListCdrsByTenantResponse createListCdrsByTenantResponse() {
        return new ListCdrsByTenantResponse();
    }

    /**
     * Create an instance of {@link GetSettingsByTenant }
     * 
     */
    public GetSettingsByTenant createGetSettingsByTenant() {
        return new GetSettingsByTenant();
    }

    /**
     * Create an instance of {@link AddInboundRoute }
     * 
     */
    public AddInboundRoute createAddInboundRoute() {
        return new AddInboundRoute();
    }

    /**
     * Create an instance of {@link ListTrunks }
     * 
     */
    public ListTrunks createListTrunks() {
        return new ListTrunks();
    }

    /**
     * Create an instance of {@link UpdateQueueResponse }
     * 
     */
    public UpdateQueueResponse createUpdateQueueResponse() {
        return new UpdateQueueResponse();
    }

    /**
     * Create an instance of {@link GetTrunkById }
     * 
     */
    public GetTrunkById createGetTrunkById() {
        return new GetTrunkById();
    }

    /**
     * Create an instance of {@link ListInboundRoutesResponse }
     * 
     */
    public ListInboundRoutesResponse createListInboundRoutesResponse() {
        return new ListInboundRoutesResponse();
    }

    /**
     * Create an instance of {@link UpdateInboundRoute }
     * 
     */
    public UpdateInboundRoute createUpdateInboundRoute() {
        return new UpdateInboundRoute();
    }

    /**
     * Create an instance of {@link GetExtenByAccountcodeResponse }
     * 
     */
    public GetExtenByAccountcodeResponse createGetExtenByAccountcodeResponse() {
        return new GetExtenByAccountcodeResponse();
    }

    /**
     * Create an instance of {@link ListQueuesByTenant }
     * 
     */
    public ListQueuesByTenant createListQueuesByTenant() {
        return new ListQueuesByTenant();
    }

    /**
     * Create an instance of {@link OnDeleteAccountResponse }
     * 
     */
    public OnDeleteAccountResponse createOnDeleteAccountResponse() {
        return new OnDeleteAccountResponse();
    }

    /**
     * Create an instance of {@link GetAccountProfileByIdResponse }
     * 
     */
    public GetAccountProfileByIdResponse createGetAccountProfileByIdResponse() {
        return new GetAccountProfileByIdResponse();
    }

    /**
     * Create an instance of {@link UpdateSettings }
     * 
     */
    public UpdateSettings createUpdateSettings() {
        return new UpdateSettings();
    }

    /**
     * Create an instance of {@link DeleteQueue }
     * 
     */
    public DeleteQueue createDeleteQueue() {
        return new DeleteQueue();
    }

    /**
     * Create an instance of {@link AddQueuemember }
     * 
     */
    public AddQueuemember createAddQueuemember() {
        return new AddQueuemember();
    }

    /**
     * Create an instance of {@link DeleteTrunk }
     * 
     */
    public DeleteTrunk createDeleteTrunk() {
        return new DeleteTrunk();
    }

    /**
     * Create an instance of {@link GetInboundRouteByIdResponse }
     * 
     */
    public GetInboundRouteByIdResponse createGetInboundRouteByIdResponse() {
        return new GetInboundRouteByIdResponse();
    }

    /**
     * Create an instance of {@link UpdateInboundRouteResponse }
     * 
     */
    public UpdateInboundRouteResponse createUpdateInboundRouteResponse() {
        return new UpdateInboundRouteResponse();
    }

    /**
     * Create an instance of {@link DeleteQueueResponse }
     * 
     */
    public DeleteQueueResponse createDeleteQueueResponse() {
        return new DeleteQueueResponse();
    }

    /**
     * Create an instance of {@link GetAccountProfileById }
     * 
     */
    public GetAccountProfileById createGetAccountProfileById() {
        return new GetAccountProfileById();
    }

    /**
     * Create an instance of {@link DeleteTrunkResponse }
     * 
     */
    public DeleteTrunkResponse createDeleteTrunkResponse() {
        return new DeleteTrunkResponse();
    }

    /**
     * Create an instance of {@link UpdateExtenResponse }
     * 
     */
    public UpdateExtenResponse createUpdateExtenResponse() {
        return new UpdateExtenResponse();
    }

    /**
     * Create an instance of {@link OnDeleteTenantResponse }
     * 
     */
    public OnDeleteTenantResponse createOnDeleteTenantResponse() {
        return new OnDeleteTenantResponse();
    }

    /**
     * Create an instance of {@link AddTrunkResponse }
     * 
     */
    public AddTrunkResponse createAddTrunkResponse() {
        return new AddTrunkResponse();
    }

    /**
     * Create an instance of {@link ListCdrsByTenant }
     * 
     */
    public ListCdrsByTenant createListCdrsByTenant() {
        return new ListCdrsByTenant();
    }

    /**
     * Create an instance of {@link ListInboundRoutes }
     * 
     */
    public ListInboundRoutes createListInboundRoutes() {
        return new ListInboundRoutes();
    }

    /**
     * Create an instance of {@link ListTrunksResponse }
     * 
     */
    public ListTrunksResponse createListTrunksResponse() {
        return new ListTrunksResponse();
    }

    /**
     * Create an instance of {@link OnDeleteAccount }
     * 
     */
    public OnDeleteAccount createOnDeleteAccount() {
        return new OnDeleteAccount();
    }

    /**
     * Create an instance of {@link GetSettingsByTenantResponse }
     * 
     */
    public GetSettingsByTenantResponse createGetSettingsByTenantResponse() {
        return new GetSettingsByTenantResponse();
    }

    /**
     * Create an instance of {@link GetInboundRouteById }
     * 
     */
    public GetInboundRouteById createGetInboundRouteById() {
        return new GetInboundRouteById();
    }

    /**
     * Create an instance of {@link UpdateTrunkResponse }
     * 
     */
    public UpdateTrunkResponse createUpdateTrunkResponse() {
        return new UpdateTrunkResponse();
    }

    /**
     * Create an instance of {@link AddTrunk }
     * 
     */
    public AddTrunk createAddTrunk() {
        return new AddTrunk();
    }

    /**
     * Create an instance of {@link DeleteInboundRoute }
     * 
     */
    public DeleteInboundRoute createDeleteInboundRoute() {
        return new DeleteInboundRoute();
    }

    /**
     * Create an instance of {@link DeleteInboundRouteResponse }
     * 
     */
    public DeleteInboundRouteResponse createDeleteInboundRouteResponse() {
        return new DeleteInboundRouteResponse();
    }

    /**
     * Create an instance of {@link AddExtenResponse }
     * 
     */
    public AddExtenResponse createAddExtenResponse() {
        return new AddExtenResponse();
    }

    /**
     * Create an instance of {@link AddQueuememberResponse }
     * 
     */
    public AddQueuememberResponse createAddQueuememberResponse() {
        return new AddQueuememberResponse();
    }

    /**
     * Create an instance of {@link UpdateExten }
     * 
     */
    public UpdateExten createUpdateExten() {
        return new UpdateExten();
    }

    /**
     * Create an instance of {@link AddQueueResponse }
     * 
     */
    public AddQueueResponse createAddQueueResponse() {
        return new AddQueueResponse();
    }

    /**
     * Create an instance of {@link UpdateQueue }
     * 
     */
    public UpdateQueue createUpdateQueue() {
        return new UpdateQueue();
    }

    /**
     * Create an instance of {@link GetTrunkByIdResponse }
     * 
     */
    public GetTrunkByIdResponse createGetTrunkByIdResponse() {
        return new GetTrunkByIdResponse();
    }

    /**
     * Create an instance of {@link GetExtenByAccountcode }
     * 
     */
    public GetExtenByAccountcode createGetExtenByAccountcode() {
        return new GetExtenByAccountcode();
    }

    /**
     * Create an instance of {@link ListQueuesByTenantResponse }
     * 
     */
    public ListQueuesByTenantResponse createListQueuesByTenantResponse() {
        return new ListQueuesByTenantResponse();
    }

    /**
     * Create an instance of {@link DeleteQueuemembersByQueue }
     * 
     */
    public DeleteQueuemembersByQueue createDeleteQueuemembersByQueue() {
        return new DeleteQueuemembersByQueue();
    }

    /**
     * Create an instance of {@link UpdateTrunk }
     * 
     */
    public UpdateTrunk createUpdateTrunk() {
        return new UpdateTrunk();
    }

    /**
     * Create an instance of {@link AddExten }
     * 
     */
    public AddExten createAddExten() {
        return new AddExten();
    }

    /**
     * Create an instance of {@link Queue }
     * 
     */
    public Queue createQueue() {
        return new Queue();
    }

    /**
     * Create an instance of {@link Recording }
     * 
     */
    public Recording createRecording() {
        return new Recording();
    }

    /**
     * Create an instance of {@link Settings }
     * 
     */
    public Settings createSettings() {
        return new Settings();
    }

    /**
     * Create an instance of {@link Conference }
     * 
     */
    public Conference createConference() {
        return new Conference();
    }

    /**
     * Create an instance of {@link Cdr }
     * 
     */
    public Cdr createCdr() {
        return new Cdr();
    }

    /**
     * Create an instance of {@link DialExtension }
     * 
     */
    public DialExtension createDialExtension() {
        return new DialExtension();
    }

    /**
     * Create an instance of {@link Trunk }
     * 
     */
    public Trunk createTrunk() {
        return new Trunk();
    }

    /**
     * Create an instance of {@link Blacklist }
     * 
     */
    public Blacklist createBlacklist() {
        return new Blacklist();
    }

    /**
     * Create an instance of {@link Pitch }
     * 
     */
    public Pitch createPitch() {
        return new Pitch();
    }

    /**
     * Create an instance of {@link AccountProfile }
     * 
     */
    public AccountProfile createAccountProfile() {
        return new AccountProfile();
    }

    /**
     * Create an instance of {@link Ivr }
     * 
     */
    public Ivr createIvr() {
        return new Ivr();
    }

    /**
     * Create an instance of {@link MusicOnHold }
     * 
     */
    public MusicOnHold createMusicOnHold() {
        return new MusicOnHold();
    }

    /**
     * Create an instance of {@link IvrResult }
     * 
     */
    public IvrResult createIvrResult() {
        return new IvrResult();
    }

    /**
     * Create an instance of {@link QueueMember }
     * 
     */
    public QueueMember createQueueMember() {
        return new QueueMember();
    }

    /**
     * Create an instance of {@link TenantProfile }
     * 
     */
    public TenantProfile createTenantProfile() {
        return new TenantProfile();
    }

    /**
     * Create an instance of {@link OutboundRoute }
     * 
     */
    public OutboundRoute createOutboundRoute() {
        return new OutboundRoute();
    }

    /**
     * Create an instance of {@link InboundRoute }
     * 
     */
    public InboundRoute createInboundRoute() {
        return new InboundRoute();
    }

    /**
     * Create an instance of {@link Voicemail }
     * 
     */
    public Voicemail createVoicemail() {
        return new Voicemail();
    }

    /**
     * Create an instance of {@link Exten }
     * 
     */
    public Exten createExten() {
        return new Exten();
    }

    /**
     * Create an instance of {@link FollowMe }
     * 
     */
    public FollowMe createFollowMe() {
        return new FollowMe();
    }

    /**
     * Create an instance of {@link IvrOption }
     * 
     */
    public IvrOption createIvrOption() {
        return new IvrOption();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "onDeleteTenant")
    public JAXBElement<OnDeleteTenant> createOnDeleteTenant(OnDeleteTenant value) {
        return new JAXBElement<OnDeleteTenant>(_OnDeleteTenant_QNAME, OnDeleteTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTenantProfileById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getTenantProfileById")
    public JAXBElement<GetTenantProfileById> createGetTenantProfileById(GetTenantProfileById value) {
        return new JAXBElement<GetTenantProfileById>(_GetTenantProfileById_QNAME, GetTenantProfileById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTenantProfileByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getTenantProfileByIdResponse")
    public JAXBElement<GetTenantProfileByIdResponse> createGetTenantProfileByIdResponse(GetTenantProfileByIdResponse value) {
        return new JAXBElement<GetTenantProfileByIdResponse>(_GetTenantProfileByIdResponse_QNAME, GetTenantProfileByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddInboundRouteResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addInboundRouteResponse")
    public JAXBElement<AddInboundRouteResponse> createAddInboundRouteResponse(AddInboundRouteResponse value) {
        return new JAXBElement<AddInboundRouteResponse>(_AddInboundRouteResponse_QNAME, AddInboundRouteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQueuemembersByQueueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteQueuemembersByQueueResponse")
    public JAXBElement<DeleteQueuemembersByQueueResponse> createDeleteQueuemembersByQueueResponse(DeleteQueuemembersByQueueResponse value) {
        return new JAXBElement<DeleteQueuemembersByQueueResponse>(_DeleteQueuemembersByQueueResponse_QNAME, DeleteQueuemembersByQueueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTrunkById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getTrunkById")
    public JAXBElement<GetTrunkById> createGetTrunkById(GetTrunkById value) {
        return new JAXBElement<GetTrunkById>(_GetTrunkById_QNAME, GetTrunkById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateQueueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateQueueResponse")
    public JAXBElement<UpdateQueueResponse> createUpdateQueueResponse(UpdateQueueResponse value) {
        return new JAXBElement<UpdateQueueResponse>(_UpdateQueueResponse_QNAME, UpdateQueueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateInboundRoute }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateInboundRoute")
    public JAXBElement<UpdateInboundRoute> createUpdateInboundRoute(UpdateInboundRoute value) {
        return new JAXBElement<UpdateInboundRoute>(_UpdateInboundRoute_QNAME, UpdateInboundRoute.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListInboundRoutesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listInboundRoutesResponse")
    public JAXBElement<ListInboundRoutesResponse> createListInboundRoutesResponse(ListInboundRoutesResponse value) {
        return new JAXBElement<ListInboundRoutesResponse>(_ListInboundRoutesResponse_QNAME, ListInboundRoutesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListQueuesByTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listQueuesByTenant")
    public JAXBElement<ListQueuesByTenant> createListQueuesByTenant(ListQueuesByTenant value) {
        return new JAXBElement<ListQueuesByTenant>(_ListQueuesByTenant_QNAME, ListQueuesByTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtenByAccountcodeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getExtenByAccountcodeResponse")
    public JAXBElement<GetExtenByAccountcodeResponse> createGetExtenByAccountcodeResponse(GetExtenByAccountcodeResponse value) {
        return new JAXBElement<GetExtenByAccountcodeResponse>(_GetExtenByAccountcodeResponse_QNAME, GetExtenByAccountcodeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSettingsByTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getSettingsByTenant")
    public JAXBElement<GetSettingsByTenant> createGetSettingsByTenant(GetSettingsByTenant value) {
        return new JAXBElement<GetSettingsByTenant>(_GetSettingsByTenant_QNAME, GetSettingsByTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListCdrsByTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listCdrsByTenantResponse")
    public JAXBElement<ListCdrsByTenantResponse> createListCdrsByTenantResponse(ListCdrsByTenantResponse value) {
        return new JAXBElement<ListCdrsByTenantResponse>(_ListCdrsByTenantResponse_QNAME, ListCdrsByTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateSettingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateSettingsResponse")
    public JAXBElement<UpdateSettingsResponse> createUpdateSettingsResponse(UpdateSettingsResponse value) {
        return new JAXBElement<UpdateSettingsResponse>(_UpdateSettingsResponse_QNAME, UpdateSettingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQueue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addQueue")
    public JAXBElement<AddQueue> createAddQueue(AddQueue value) {
        return new JAXBElement<AddQueue>(_AddQueue_QNAME, AddQueue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListTrunks }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listTrunks")
    public JAXBElement<ListTrunks> createListTrunks(ListTrunks value) {
        return new JAXBElement<ListTrunks>(_ListTrunks_QNAME, ListTrunks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddInboundRoute }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addInboundRoute")
    public JAXBElement<AddInboundRoute> createAddInboundRoute(AddInboundRoute value) {
        return new JAXBElement<AddInboundRoute>(_AddInboundRoute_QNAME, AddInboundRoute.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateInboundRouteResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateInboundRouteResponse")
    public JAXBElement<UpdateInboundRouteResponse> createUpdateInboundRouteResponse(UpdateInboundRouteResponse value) {
        return new JAXBElement<UpdateInboundRouteResponse>(_UpdateInboundRouteResponse_QNAME, UpdateInboundRouteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateExtenResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateExtenResponse")
    public JAXBElement<UpdateExtenResponse> createUpdateExtenResponse(UpdateExtenResponse value) {
        return new JAXBElement<UpdateExtenResponse>(_UpdateExtenResponse_QNAME, UpdateExtenResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "onDeleteTenantResponse")
    public JAXBElement<OnDeleteTenantResponse> createOnDeleteTenantResponse(OnDeleteTenantResponse value) {
        return new JAXBElement<OnDeleteTenantResponse>(_OnDeleteTenantResponse_QNAME, OnDeleteTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteTrunkResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteTrunkResponse")
    public JAXBElement<DeleteTrunkResponse> createDeleteTrunkResponse(DeleteTrunkResponse value) {
        return new JAXBElement<DeleteTrunkResponse>(_DeleteTrunkResponse_QNAME, DeleteTrunkResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQueueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteQueueResponse")
    public JAXBElement<DeleteQueueResponse> createDeleteQueueResponse(DeleteQueueResponse value) {
        return new JAXBElement<DeleteQueueResponse>(_DeleteQueueResponse_QNAME, DeleteQueueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountProfileById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getAccountProfileById")
    public JAXBElement<GetAccountProfileById> createGetAccountProfileById(GetAccountProfileById value) {
        return new JAXBElement<GetAccountProfileById>(_GetAccountProfileById_QNAME, GetAccountProfileById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateSettings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateSettings")
    public JAXBElement<UpdateSettings> createUpdateSettings(UpdateSettings value) {
        return new JAXBElement<UpdateSettings>(_UpdateSettings_QNAME, UpdateSettings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQueuemember }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addQueuemember")
    public JAXBElement<AddQueuemember> createAddQueuemember(AddQueuemember value) {
        return new JAXBElement<AddQueuemember>(_AddQueuemember_QNAME, AddQueuemember.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQueue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteQueue")
    public JAXBElement<DeleteQueue> createDeleteQueue(DeleteQueue value) {
        return new JAXBElement<DeleteQueue>(_DeleteQueue_QNAME, DeleteQueue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "onDeleteAccountResponse")
    public JAXBElement<OnDeleteAccountResponse> createOnDeleteAccountResponse(OnDeleteAccountResponse value) {
        return new JAXBElement<OnDeleteAccountResponse>(_OnDeleteAccountResponse_QNAME, OnDeleteAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountProfileByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getAccountProfileByIdResponse")
    public JAXBElement<GetAccountProfileByIdResponse> createGetAccountProfileByIdResponse(GetAccountProfileByIdResponse value) {
        return new JAXBElement<GetAccountProfileByIdResponse>(_GetAccountProfileByIdResponse_QNAME, GetAccountProfileByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteTrunk }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteTrunk")
    public JAXBElement<DeleteTrunk> createDeleteTrunk(DeleteTrunk value) {
        return new JAXBElement<DeleteTrunk>(_DeleteTrunk_QNAME, DeleteTrunk.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetInboundRouteByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getInboundRouteByIdResponse")
    public JAXBElement<GetInboundRouteByIdResponse> createGetInboundRouteByIdResponse(GetInboundRouteByIdResponse value) {
        return new JAXBElement<GetInboundRouteByIdResponse>(_GetInboundRouteByIdResponse_QNAME, GetInboundRouteByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateExten }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateExten")
    public JAXBElement<UpdateExten> createUpdateExten(UpdateExten value) {
        return new JAXBElement<UpdateExten>(_UpdateExten_QNAME, UpdateExten.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQueueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addQueueResponse")
    public JAXBElement<AddQueueResponse> createAddQueueResponse(AddQueueResponse value) {
        return new JAXBElement<AddQueueResponse>(_AddQueueResponse_QNAME, AddQueueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateQueue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateQueue")
    public JAXBElement<UpdateQueue> createUpdateQueue(UpdateQueue value) {
        return new JAXBElement<UpdateQueue>(_UpdateQueue_QNAME, UpdateQueue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteInboundRouteResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteInboundRouteResponse")
    public JAXBElement<DeleteInboundRouteResponse> createDeleteInboundRouteResponse(DeleteInboundRouteResponse value) {
        return new JAXBElement<DeleteInboundRouteResponse>(_DeleteInboundRouteResponse_QNAME, DeleteInboundRouteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddExtenResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addExtenResponse")
    public JAXBElement<AddExtenResponse> createAddExtenResponse(AddExtenResponse value) {
        return new JAXBElement<AddExtenResponse>(_AddExtenResponse_QNAME, AddExtenResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQueuememberResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addQueuememberResponse")
    public JAXBElement<AddQueuememberResponse> createAddQueuememberResponse(AddQueuememberResponse value) {
        return new JAXBElement<AddQueuememberResponse>(_AddQueuememberResponse_QNAME, AddQueuememberResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddExten }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addExten")
    public JAXBElement<AddExten> createAddExten(AddExten value) {
        return new JAXBElement<AddExten>(_AddExten_QNAME, AddExten.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateTrunk }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateTrunk")
    public JAXBElement<UpdateTrunk> createUpdateTrunk(UpdateTrunk value) {
        return new JAXBElement<UpdateTrunk>(_UpdateTrunk_QNAME, UpdateTrunk.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListQueuesByTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listQueuesByTenantResponse")
    public JAXBElement<ListQueuesByTenantResponse> createListQueuesByTenantResponse(ListQueuesByTenantResponse value) {
        return new JAXBElement<ListQueuesByTenantResponse>(_ListQueuesByTenantResponse_QNAME, ListQueuesByTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQueuemembersByQueue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteQueuemembersByQueue")
    public JAXBElement<DeleteQueuemembersByQueue> createDeleteQueuemembersByQueue(DeleteQueuemembersByQueue value) {
        return new JAXBElement<DeleteQueuemembersByQueue>(_DeleteQueuemembersByQueue_QNAME, DeleteQueuemembersByQueue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTrunkByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getTrunkByIdResponse")
    public JAXBElement<GetTrunkByIdResponse> createGetTrunkByIdResponse(GetTrunkByIdResponse value) {
        return new JAXBElement<GetTrunkByIdResponse>(_GetTrunkByIdResponse_QNAME, GetTrunkByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtenByAccountcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getExtenByAccountcode")
    public JAXBElement<GetExtenByAccountcode> createGetExtenByAccountcode(GetExtenByAccountcode value) {
        return new JAXBElement<GetExtenByAccountcode>(_GetExtenByAccountcode_QNAME, GetExtenByAccountcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetInboundRouteById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getInboundRouteById")
    public JAXBElement<GetInboundRouteById> createGetInboundRouteById(GetInboundRouteById value) {
        return new JAXBElement<GetInboundRouteById>(_GetInboundRouteById_QNAME, GetInboundRouteById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSettingsByTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getSettingsByTenantResponse")
    public JAXBElement<GetSettingsByTenantResponse> createGetSettingsByTenantResponse(GetSettingsByTenantResponse value) {
        return new JAXBElement<GetSettingsByTenantResponse>(_GetSettingsByTenantResponse_QNAME, GetSettingsByTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListCdrsByTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listCdrsByTenant")
    public JAXBElement<ListCdrsByTenant> createListCdrsByTenant(ListCdrsByTenant value) {
        return new JAXBElement<ListCdrsByTenant>(_ListCdrsByTenant_QNAME, ListCdrsByTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListInboundRoutes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listInboundRoutes")
    public JAXBElement<ListInboundRoutes> createListInboundRoutes(ListInboundRoutes value) {
        return new JAXBElement<ListInboundRoutes>(_ListInboundRoutes_QNAME, ListInboundRoutes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListTrunksResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listTrunksResponse")
    public JAXBElement<ListTrunksResponse> createListTrunksResponse(ListTrunksResponse value) {
        return new JAXBElement<ListTrunksResponse>(_ListTrunksResponse_QNAME, ListTrunksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "onDeleteAccount")
    public JAXBElement<OnDeleteAccount> createOnDeleteAccount(OnDeleteAccount value) {
        return new JAXBElement<OnDeleteAccount>(_OnDeleteAccount_QNAME, OnDeleteAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTrunkResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addTrunkResponse")
    public JAXBElement<AddTrunkResponse> createAddTrunkResponse(AddTrunkResponse value) {
        return new JAXBElement<AddTrunkResponse>(_AddTrunkResponse_QNAME, AddTrunkResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteInboundRoute }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteInboundRoute")
    public JAXBElement<DeleteInboundRoute> createDeleteInboundRoute(DeleteInboundRoute value) {
        return new JAXBElement<DeleteInboundRoute>(_DeleteInboundRoute_QNAME, DeleteInboundRoute.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTrunk }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addTrunk")
    public JAXBElement<AddTrunk> createAddTrunk(AddTrunk value) {
        return new JAXBElement<AddTrunk>(_AddTrunk_QNAME, AddTrunk.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateTrunkResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateTrunkResponse")
    public JAXBElement<UpdateTrunkResponse> createUpdateTrunkResponse(UpdateTrunkResponse value) {
        return new JAXBElement<UpdateTrunkResponse>(_UpdateTrunkResponse_QNAME, UpdateTrunkResponse.class, null, value);
    }

}
