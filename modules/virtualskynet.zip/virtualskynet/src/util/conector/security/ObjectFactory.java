
package util.conector.security;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the util.conector.security package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AddAccount_QNAME = new QName("http://ws.api/", "addAccount");
    private final static QName _DeleteTenantResponse_QNAME = new QName("http://ws.api/", "deleteTenantResponse");
    private final static QName _UpdateAccountResponse_QNAME = new QName("http://ws.api/", "updateAccountResponse");
    private final static QName _TenantRegisterResponse_QNAME = new QName("http://ws.api/", "tenantRegisterResponse");
    private final static QName _AccountLoginResponse_QNAME = new QName("http://ws.api/", "accountLoginResponse");
    private final static QName _TenantRemember_QNAME = new QName("http://ws.api/", "tenantRemember");
    private final static QName _GetAccountByEmail_QNAME = new QName("http://ws.api/", "getAccountByEmail");
    private final static QName _TenantRegister_QNAME = new QName("http://ws.api/", "tenantRegister");
    private final static QName _GetSession_QNAME = new QName("http://ws.api/", "getSession");
    private final static QName _AddTenantResponse_QNAME = new QName("http://ws.api/", "addTenantResponse");
    private final static QName _AccountLogin_QNAME = new QName("http://ws.api/", "accountLogin");
    private final static QName _ListAccounts_QNAME = new QName("http://ws.api/", "listAccounts");
    private final static QName _ListAccountsResponse_QNAME = new QName("http://ws.api/", "listAccountsResponse");
    private final static QName _UpdateTenant_QNAME = new QName("http://ws.api/", "updateTenant");
    private final static QName _ListTenantsResponse_QNAME = new QName("http://ws.api/", "listTenantsResponse");
    private final static QName _TenantRememberResponse_QNAME = new QName("http://ws.api/", "tenantRememberResponse");
    private final static QName _DeleteAccountResponse_QNAME = new QName("http://ws.api/", "deleteAccountResponse");
    private final static QName _AddTenant_QNAME = new QName("http://ws.api/", "addTenant");
    private final static QName _UpdateAccount_QNAME = new QName("http://ws.api/", "updateAccount");
    private final static QName _ListTenants_QNAME = new QName("http://ws.api/", "listTenants");
    private final static QName _UpdateTenantResponse_QNAME = new QName("http://ws.api/", "updateTenantResponse");
    private final static QName _DeleteTenant_QNAME = new QName("http://ws.api/", "deleteTenant");
    private final static QName _CloseSessionResponse_QNAME = new QName("http://ws.api/", "closeSessionResponse");
    private final static QName _CloseSession_QNAME = new QName("http://ws.api/", "closeSession");
    private final static QName _GetSessionResponse_QNAME = new QName("http://ws.api/", "getSessionResponse");
    private final static QName _TenantLogin_QNAME = new QName("http://ws.api/", "tenantLogin");
    private final static QName _AddAccountResponse_QNAME = new QName("http://ws.api/", "addAccountResponse");
    private final static QName _GetAccountByEmailResponse_QNAME = new QName("http://ws.api/", "getAccountByEmailResponse");
    private final static QName _TenantLoginResponse_QNAME = new QName("http://ws.api/", "tenantLoginResponse");
    private final static QName _DeleteAccount_QNAME = new QName("http://ws.api/", "deleteAccount");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: util.conector.security
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateTenant }
     * 
     */
    public UpdateTenant createUpdateTenant() {
        return new UpdateTenant();
    }

    /**
     * Create an instance of {@link ListAccountsResponse }
     * 
     */
    public ListAccountsResponse createListAccountsResponse() {
        return new ListAccountsResponse();
    }

    /**
     * Create an instance of {@link ListTenantsResponse }
     * 
     */
    public ListTenantsResponse createListTenantsResponse() {
        return new ListTenantsResponse();
    }

    /**
     * Create an instance of {@link ListAccounts }
     * 
     */
    public ListAccounts createListAccounts() {
        return new ListAccounts();
    }

    /**
     * Create an instance of {@link AccountLogin }
     * 
     */
    public AccountLogin createAccountLogin() {
        return new AccountLogin();
    }

    /**
     * Create an instance of {@link TenantRememberResponse }
     * 
     */
    public TenantRememberResponse createTenantRememberResponse() {
        return new TenantRememberResponse();
    }

    /**
     * Create an instance of {@link DeleteAccountResponse }
     * 
     */
    public DeleteAccountResponse createDeleteAccountResponse() {
        return new DeleteAccountResponse();
    }

    /**
     * Create an instance of {@link TenantRemember }
     * 
     */
    public TenantRemember createTenantRemember() {
        return new TenantRemember();
    }

    /**
     * Create an instance of {@link AccountLoginResponse }
     * 
     */
    public AccountLoginResponse createAccountLoginResponse() {
        return new AccountLoginResponse();
    }

    /**
     * Create an instance of {@link UpdateAccountResponse }
     * 
     */
    public UpdateAccountResponse createUpdateAccountResponse() {
        return new UpdateAccountResponse();
    }

    /**
     * Create an instance of {@link DeleteTenantResponse }
     * 
     */
    public DeleteTenantResponse createDeleteTenantResponse() {
        return new DeleteTenantResponse();
    }

    /**
     * Create an instance of {@link TenantRegisterResponse }
     * 
     */
    public TenantRegisterResponse createTenantRegisterResponse() {
        return new TenantRegisterResponse();
    }

    /**
     * Create an instance of {@link AddAccount }
     * 
     */
    public AddAccount createAddAccount() {
        return new AddAccount();
    }

    /**
     * Create an instance of {@link GetSession }
     * 
     */
    public GetSession createGetSession() {
        return new GetSession();
    }

    /**
     * Create an instance of {@link AddTenantResponse }
     * 
     */
    public AddTenantResponse createAddTenantResponse() {
        return new AddTenantResponse();
    }

    /**
     * Create an instance of {@link GetAccountByEmail }
     * 
     */
    public GetAccountByEmail createGetAccountByEmail() {
        return new GetAccountByEmail();
    }

    /**
     * Create an instance of {@link TenantRegister }
     * 
     */
    public TenantRegister createTenantRegister() {
        return new TenantRegister();
    }

    /**
     * Create an instance of {@link AddAccountResponse }
     * 
     */
    public AddAccountResponse createAddAccountResponse() {
        return new AddAccountResponse();
    }

    /**
     * Create an instance of {@link GetAccountByEmailResponse }
     * 
     */
    public GetAccountByEmailResponse createGetAccountByEmailResponse() {
        return new GetAccountByEmailResponse();
    }

    /**
     * Create an instance of {@link CloseSession }
     * 
     */
    public CloseSession createCloseSession() {
        return new CloseSession();
    }

    /**
     * Create an instance of {@link GetSessionResponse }
     * 
     */
    public GetSessionResponse createGetSessionResponse() {
        return new GetSessionResponse();
    }

    /**
     * Create an instance of {@link TenantLogin }
     * 
     */
    public TenantLogin createTenantLogin() {
        return new TenantLogin();
    }

    /**
     * Create an instance of {@link TenantLoginResponse }
     * 
     */
    public TenantLoginResponse createTenantLoginResponse() {
        return new TenantLoginResponse();
    }

    /**
     * Create an instance of {@link DeleteAccount }
     * 
     */
    public DeleteAccount createDeleteAccount() {
        return new DeleteAccount();
    }

    /**
     * Create an instance of {@link ListTenants }
     * 
     */
    public ListTenants createListTenants() {
        return new ListTenants();
    }

    /**
     * Create an instance of {@link UpdateAccount }
     * 
     */
    public UpdateAccount createUpdateAccount() {
        return new UpdateAccount();
    }

    /**
     * Create an instance of {@link AddTenant }
     * 
     */
    public AddTenant createAddTenant() {
        return new AddTenant();
    }

    /**
     * Create an instance of {@link DeleteTenant }
     * 
     */
    public DeleteTenant createDeleteTenant() {
        return new DeleteTenant();
    }

    /**
     * Create an instance of {@link CloseSessionResponse }
     * 
     */
    public CloseSessionResponse createCloseSessionResponse() {
        return new CloseSessionResponse();
    }

    /**
     * Create an instance of {@link UpdateTenantResponse }
     * 
     */
    public UpdateTenantResponse createUpdateTenantResponse() {
        return new UpdateTenantResponse();
    }

    /**
     * Create an instance of {@link Tenant }
     * 
     */
    public Tenant createTenant() {
        return new Tenant();
    }

    /**
     * Create an instance of {@link Role }
     * 
     */
    public Role createRole() {
        return new Role();
    }

    /**
     * Create an instance of {@link Session }
     * 
     */
    public Session createSession() {
        return new Session();
    }

    /**
     * Create an instance of {@link Account }
     * 
     */
    public Account createAccount() {
        return new Account();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addAccount")
    public JAXBElement<AddAccount> createAddAccount(AddAccount value) {
        return new JAXBElement<AddAccount>(_AddAccount_QNAME, AddAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteTenantResponse")
    public JAXBElement<DeleteTenantResponse> createDeleteTenantResponse(DeleteTenantResponse value) {
        return new JAXBElement<DeleteTenantResponse>(_DeleteTenantResponse_QNAME, DeleteTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateAccountResponse")
    public JAXBElement<UpdateAccountResponse> createUpdateAccountResponse(UpdateAccountResponse value) {
        return new JAXBElement<UpdateAccountResponse>(_UpdateAccountResponse_QNAME, UpdateAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantRegisterResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantRegisterResponse")
    public JAXBElement<TenantRegisterResponse> createTenantRegisterResponse(TenantRegisterResponse value) {
        return new JAXBElement<TenantRegisterResponse>(_TenantRegisterResponse_QNAME, TenantRegisterResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountLoginResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "accountLoginResponse")
    public JAXBElement<AccountLoginResponse> createAccountLoginResponse(AccountLoginResponse value) {
        return new JAXBElement<AccountLoginResponse>(_AccountLoginResponse_QNAME, AccountLoginResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantRemember }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantRemember")
    public JAXBElement<TenantRemember> createTenantRemember(TenantRemember value) {
        return new JAXBElement<TenantRemember>(_TenantRemember_QNAME, TenantRemember.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getAccountByEmail")
    public JAXBElement<GetAccountByEmail> createGetAccountByEmail(GetAccountByEmail value) {
        return new JAXBElement<GetAccountByEmail>(_GetAccountByEmail_QNAME, GetAccountByEmail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantRegister }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantRegister")
    public JAXBElement<TenantRegister> createTenantRegister(TenantRegister value) {
        return new JAXBElement<TenantRegister>(_TenantRegister_QNAME, TenantRegister.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getSession")
    public JAXBElement<GetSession> createGetSession(GetSession value) {
        return new JAXBElement<GetSession>(_GetSession_QNAME, GetSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addTenantResponse")
    public JAXBElement<AddTenantResponse> createAddTenantResponse(AddTenantResponse value) {
        return new JAXBElement<AddTenantResponse>(_AddTenantResponse_QNAME, AddTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountLogin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "accountLogin")
    public JAXBElement<AccountLogin> createAccountLogin(AccountLogin value) {
        return new JAXBElement<AccountLogin>(_AccountLogin_QNAME, AccountLogin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccounts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listAccounts")
    public JAXBElement<ListAccounts> createListAccounts(ListAccounts value) {
        return new JAXBElement<ListAccounts>(_ListAccounts_QNAME, ListAccounts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccountsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listAccountsResponse")
    public JAXBElement<ListAccountsResponse> createListAccountsResponse(ListAccountsResponse value) {
        return new JAXBElement<ListAccountsResponse>(_ListAccountsResponse_QNAME, ListAccountsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateTenant")
    public JAXBElement<UpdateTenant> createUpdateTenant(UpdateTenant value) {
        return new JAXBElement<UpdateTenant>(_UpdateTenant_QNAME, UpdateTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListTenantsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listTenantsResponse")
    public JAXBElement<ListTenantsResponse> createListTenantsResponse(ListTenantsResponse value) {
        return new JAXBElement<ListTenantsResponse>(_ListTenantsResponse_QNAME, ListTenantsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantRememberResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantRememberResponse")
    public JAXBElement<TenantRememberResponse> createTenantRememberResponse(TenantRememberResponse value) {
        return new JAXBElement<TenantRememberResponse>(_TenantRememberResponse_QNAME, TenantRememberResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteAccountResponse")
    public JAXBElement<DeleteAccountResponse> createDeleteAccountResponse(DeleteAccountResponse value) {
        return new JAXBElement<DeleteAccountResponse>(_DeleteAccountResponse_QNAME, DeleteAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addTenant")
    public JAXBElement<AddTenant> createAddTenant(AddTenant value) {
        return new JAXBElement<AddTenant>(_AddTenant_QNAME, AddTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateAccount")
    public JAXBElement<UpdateAccount> createUpdateAccount(UpdateAccount value) {
        return new JAXBElement<UpdateAccount>(_UpdateAccount_QNAME, UpdateAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListTenants }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "listTenants")
    public JAXBElement<ListTenants> createListTenants(ListTenants value) {
        return new JAXBElement<ListTenants>(_ListTenants_QNAME, ListTenants.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateTenantResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "updateTenantResponse")
    public JAXBElement<UpdateTenantResponse> createUpdateTenantResponse(UpdateTenantResponse value) {
        return new JAXBElement<UpdateTenantResponse>(_UpdateTenantResponse_QNAME, UpdateTenantResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteTenant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteTenant")
    public JAXBElement<DeleteTenant> createDeleteTenant(DeleteTenant value) {
        return new JAXBElement<DeleteTenant>(_DeleteTenant_QNAME, DeleteTenant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "closeSessionResponse")
    public JAXBElement<CloseSessionResponse> createCloseSessionResponse(CloseSessionResponse value) {
        return new JAXBElement<CloseSessionResponse>(_CloseSessionResponse_QNAME, CloseSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "closeSession")
    public JAXBElement<CloseSession> createCloseSession(CloseSession value) {
        return new JAXBElement<CloseSession>(_CloseSession_QNAME, CloseSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getSessionResponse")
    public JAXBElement<GetSessionResponse> createGetSessionResponse(GetSessionResponse value) {
        return new JAXBElement<GetSessionResponse>(_GetSessionResponse_QNAME, GetSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantLogin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantLogin")
    public JAXBElement<TenantLogin> createTenantLogin(TenantLogin value) {
        return new JAXBElement<TenantLogin>(_TenantLogin_QNAME, TenantLogin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "addAccountResponse")
    public JAXBElement<AddAccountResponse> createAddAccountResponse(AddAccountResponse value) {
        return new JAXBElement<AddAccountResponse>(_AddAccountResponse_QNAME, AddAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "getAccountByEmailResponse")
    public JAXBElement<GetAccountByEmailResponse> createGetAccountByEmailResponse(GetAccountByEmailResponse value) {
        return new JAXBElement<GetAccountByEmailResponse>(_GetAccountByEmailResponse_QNAME, GetAccountByEmailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TenantLoginResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "tenantLoginResponse")
    public JAXBElement<TenantLoginResponse> createTenantLoginResponse(TenantLoginResponse value) {
        return new JAXBElement<TenantLoginResponse>(_TenantLoginResponse_QNAME, TenantLoginResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.api/", name = "deleteAccount")
    public JAXBElement<DeleteAccount> createDeleteAccount(DeleteAccount value) {
        return new JAXBElement<DeleteAccount>(_DeleteAccount_QNAME, DeleteAccount.class, null, value);
    }

}
