package util;

import javax.ejb.Stateless;

import util.conector.backend.Session;
import util.conector.backend.VirtualWS;
import util.conector.backend.VirtualWSService;


@Stateless
public class Util {
		
	//RemoteTest
	VirtualWS virtualWS = new VirtualWSService().getVirtualWSPort();
	

	public VirtualWS getService() {
		return virtualWS;
	}
		
	public void closeSession() {
		if(getSession()!=null){
			FacesUtils.getSession().invalidate();
			FacesUtils.setCookie("portaltoken", null);
			getService().closeSession(getSession().getToken());
		} 
	}	

	public Session getSession() {
		Session result = null;
		String token = FacesUtils.getCookieValue("portaltoken");
		if(token!=null){
			result = getService().getSession(token);
		}
		return result; 
	}
	
}
