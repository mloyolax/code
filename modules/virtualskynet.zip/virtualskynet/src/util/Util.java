package util;

import javax.ejb.Stateless;
import util.conector.pbx.PbxWS;
import util.conector.pbx.PbxWSService;
import util.conector.security.SecurityWS;
import util.conector.security.SecurityWSService;
import util.conector.security.Session;


@Stateless
public class Util {
		
	//RemoteTest
	SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();
	PbxWS pbxWS = new PbxWSService().getPbxWSPort();	

	public SecurityWS getSecurityWS() {
		return securityWS;
	}
	public PbxWS getPbxWS() {
		return pbxWS;
	}
	
	public void closeSession() {
		if(getSession()!=null){
			FacesUtils.getSession().invalidate();
			FacesUtils.setCookie("portaltoken", null);
			getSecurityWS().closeSession(getSession().getToken());
		} 
	}	

	public Session getSession() {
		Session result = null;
		String token = FacesUtils.getCookieValue("portaltoken");
		if(token!=null){
			result = getSecurityWS().getSession(token);
		}
		return result; 
	}
		 

}
