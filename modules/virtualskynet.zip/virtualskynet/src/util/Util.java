package util;

import javax.ejb.Singleton;
import util.conector.security.SecurityWS;
import util.conector.security.SecurityWSService;
import util.conector.security.Session;


@Singleton
public class Util {
		
	//Add Services Here!!
	SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();
	
	public SecurityWS getSecurityWS() {	        
		return securityWS;
	}	


	public void closeSession() {
		if(getSession()!=null){
			FacesUtils.setCookie("portaltoken", null);
			securityWS.closeSession(getSession().getToken());
		} 
	}	

	public Session getSession() {
		Session result = null;
		String token = FacesUtils.getCookieValue("portaltoken");
		if(token!=null){
			result = securityWS.getSession(token);
		}
		return result; 
	}
		 

}
