package util.test;

//import org.apache.cxf.endpoint.Server;
//import org.apache.cxf.jaxrs.client.WebClient;


public class RESTClient {
	 
  //  static Server server;
 

    public static void setUp() {
    	//nothing
    }
 
    public void getAccount() {
    	
    //    WebClient client = WebClient.create("http://204.51.97.107");
        //client.path("skynet/security/account/helllo");
		//client.accept("application/json");
		//client.type("application/json");
		//client.query("id", "1");
        
        //String result = client.get(String.class);
        //System.out.println("Response:" + result);
			
	
    }
     
    public static void tearDown() {
        //server.destroy();
    }
}