package util.test;


public class TestWS {


	public static void main(String[] args) {
		
		/*SecuritySuperWS securitySuperWS = new SecuritySuperWSService().getSecuritySuperWSPort();
		SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();
		
		Map<String, Object> req_ctx = ((BindingProvider)securityWS).getRequestContext();		
		Map<String, List<String>> headers = new HashMap<String, List<String>>();
        headers.put("portaltoken", Collections.singletonList("ABC1234"));
        req_ctx.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
		
    	
    	System.out.println(securitySuperWS.listAccounts(0, 0));
        String token = securityWS.doLogin("superadmin@virtualskynet.com", "123456");
    	System.out.println("FROM WS - " + token);*/
		
		
		//PbxWS pbxWS = new PbxWSService().getPbxWSPort();
		/*public PbxWS getPbxWS() {
			Map<String, Object> req_ctx = ((BindingProvider)pbxWS).getRequestContext();		
			Map<String, List<String>> headers = new HashMap<String, List<String>>();
	        headers.put("portaltoken", Collections.singletonList("ABC1234"));
	        req_ctx.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
			return pbxWS;
		}*/
		

	}

}
