package test;


public class SOAPClient {
	

    public static void setUp() {
    	//nothing
    }
 
    public void getAccount() throws Exception {
    	
    	//SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();

    	//Account account = securityWS.getAccountByEmailPassword("superadmin@virtualskynet.com", "p4ssw0rd");
    	//System.out.println("FROM WS - " + account.getFirstname() + " / " +account.getOrganization().getName());
    	
    }
 
    public static void tearDown() {
    }
}