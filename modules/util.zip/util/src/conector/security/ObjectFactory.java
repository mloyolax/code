
package conector.security;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the conector.security package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListAccountsByOrganization_QNAME = new QName("http://ws.security/", "listAccountsByOrganization");
    private final static QName _DeleteAccount_QNAME = new QName("http://ws.security/", "deleteAccount");
    private final static QName _RememberPassword_QNAME = new QName("http://ws.security/", "rememberPassword");
    private final static QName _UpdateRole_QNAME = new QName("http://ws.security/", "updateRole");
    private final static QName _GetSessionByTokenResponse_QNAME = new QName("http://ws.security/", "getSessionByTokenResponse");
    private final static QName _UpdateOrganization_QNAME = new QName("http://ws.security/", "updateOrganization");
    private final static QName _AddRole_QNAME = new QName("http://ws.security/", "addRole");
    private final static QName _DeleteRoleResponse_QNAME = new QName("http://ws.security/", "deleteRoleResponse");
    private final static QName _ListRoles_QNAME = new QName("http://ws.security/", "listRoles");
    private final static QName _AddOrganization_QNAME = new QName("http://ws.security/", "addOrganization");
    private final static QName _AddAccountResponse_QNAME = new QName("http://ws.security/", "addAccountResponse");
    private final static QName _GetAccountByEmailResponse_QNAME = new QName("http://ws.security/", "getAccountByEmailResponse");
    private final static QName _DeleteOrganizationResponse_QNAME = new QName("http://ws.security/", "deleteOrganizationResponse");
    private final static QName _DeleteRole_QNAME = new QName("http://ws.security/", "deleteRole");
    private final static QName _CloseSession_QNAME = new QName("http://ws.security/", "closeSession");
    private final static QName _GetAccountByEmailPasswordResponse_QNAME = new QName("http://ws.security/", "getAccountByEmailPasswordResponse");
    private final static QName _RememberPasswordResponse_QNAME = new QName("http://ws.security/", "rememberPasswordResponse");
    private final static QName _UpdateRoleResponse_QNAME = new QName("http://ws.security/", "updateRoleResponse");
    private final static QName _ListOrganizationsResponse_QNAME = new QName("http://ws.security/", "listOrganizationsResponse");
    private final static QName _CloseSessionResponse_QNAME = new QName("http://ws.security/", "closeSessionResponse");
    private final static QName _UpdateAccount_QNAME = new QName("http://ws.security/", "updateAccount");
    private final static QName _AddOrganizationResponse_QNAME = new QName("http://ws.security/", "addOrganizationResponse");
    private final static QName _NewRegisterResponse_QNAME = new QName("http://ws.security/", "newRegisterResponse");
    private final static QName _UpdateOrganizationResponse_QNAME = new QName("http://ws.security/", "updateOrganizationResponse");
    private final static QName _ListAccountsByOrganizationResponse_QNAME = new QName("http://ws.security/", "listAccountsByOrganizationResponse");
    private final static QName _DoLogin_QNAME = new QName("http://ws.security/", "doLogin");
    private final static QName _DoLoginResponse_QNAME = new QName("http://ws.security/", "doLoginResponse");
    private final static QName _GetSessionByToken_QNAME = new QName("http://ws.security/", "getSessionByToken");
    private final static QName _GetAccountByEmailPassword_QNAME = new QName("http://ws.security/", "getAccountByEmailPassword");
    private final static QName _DeleteOrganization_QNAME = new QName("http://ws.security/", "deleteOrganization");
    private final static QName _ListRolesResponse_QNAME = new QName("http://ws.security/", "listRolesResponse");
    private final static QName _DeleteAccountResponse_QNAME = new QName("http://ws.security/", "deleteAccountResponse");
    private final static QName _ListAccounts_QNAME = new QName("http://ws.security/", "listAccounts");
    private final static QName _ListOrganizations_QNAME = new QName("http://ws.security/", "listOrganizations");
    private final static QName _AddRoleResponse_QNAME = new QName("http://ws.security/", "addRoleResponse");
    private final static QName _ListAccountsResponse_QNAME = new QName("http://ws.security/", "listAccountsResponse");
    private final static QName _GetAccountByEmail_QNAME = new QName("http://ws.security/", "getAccountByEmail");
    private final static QName _UpdateAccountResponse_QNAME = new QName("http://ws.security/", "updateAccountResponse");
    private final static QName _AddAccount_QNAME = new QName("http://ws.security/", "addAccount");
    private final static QName _NewRegister_QNAME = new QName("http://ws.security/", "newRegister");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: conector.security
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListAccountsResponse }
     * 
     */
    public ListAccountsResponse createListAccountsResponse() {
        return new ListAccountsResponse();
    }

    /**
     * Create an instance of {@link ListAccounts }
     * 
     */
    public ListAccounts createListAccounts() {
        return new ListAccounts();
    }

    /**
     * Create an instance of {@link ListOrganizations }
     * 
     */
    public ListOrganizations createListOrganizations() {
        return new ListOrganizations();
    }

    /**
     * Create an instance of {@link AddRoleResponse }
     * 
     */
    public AddRoleResponse createAddRoleResponse() {
        return new AddRoleResponse();
    }

    /**
     * Create an instance of {@link GetSessionByToken }
     * 
     */
    public GetSessionByToken createGetSessionByToken() {
        return new GetSessionByToken();
    }

    /**
     * Create an instance of {@link ListRolesResponse }
     * 
     */
    public ListRolesResponse createListRolesResponse() {
        return new ListRolesResponse();
    }

    /**
     * Create an instance of {@link DeleteOrganization }
     * 
     */
    public DeleteOrganization createDeleteOrganization() {
        return new DeleteOrganization();
    }

    /**
     * Create an instance of {@link GetAccountByEmailPassword }
     * 
     */
    public GetAccountByEmailPassword createGetAccountByEmailPassword() {
        return new GetAccountByEmailPassword();
    }

    /**
     * Create an instance of {@link DeleteAccountResponse }
     * 
     */
    public DeleteAccountResponse createDeleteAccountResponse() {
        return new DeleteAccountResponse();
    }

    /**
     * Create an instance of {@link DoLoginResponse }
     * 
     */
    public DoLoginResponse createDoLoginResponse() {
        return new DoLoginResponse();
    }

    /**
     * Create an instance of {@link NewRegister }
     * 
     */
    public NewRegister createNewRegister() {
        return new NewRegister();
    }

    /**
     * Create an instance of {@link UpdateAccountResponse }
     * 
     */
    public UpdateAccountResponse createUpdateAccountResponse() {
        return new UpdateAccountResponse();
    }

    /**
     * Create an instance of {@link AddAccount }
     * 
     */
    public AddAccount createAddAccount() {
        return new AddAccount();
    }

    /**
     * Create an instance of {@link GetAccountByEmail }
     * 
     */
    public GetAccountByEmail createGetAccountByEmail() {
        return new GetAccountByEmail();
    }

    /**
     * Create an instance of {@link ListRoles }
     * 
     */
    public ListRoles createListRoles() {
        return new ListRoles();
    }

    /**
     * Create an instance of {@link AddOrganization }
     * 
     */
    public AddOrganization createAddOrganization() {
        return new AddOrganization();
    }

    /**
     * Create an instance of {@link AddAccountResponse }
     * 
     */
    public AddAccountResponse createAddAccountResponse() {
        return new AddAccountResponse();
    }

    /**
     * Create an instance of {@link GetAccountByEmailResponse }
     * 
     */
    public GetAccountByEmailResponse createGetAccountByEmailResponse() {
        return new GetAccountByEmailResponse();
    }

    /**
     * Create an instance of {@link DeleteOrganizationResponse }
     * 
     */
    public DeleteOrganizationResponse createDeleteOrganizationResponse() {
        return new DeleteOrganizationResponse();
    }

    /**
     * Create an instance of {@link DeleteRole }
     * 
     */
    public DeleteRole createDeleteRole() {
        return new DeleteRole();
    }

    /**
     * Create an instance of {@link CloseSession }
     * 
     */
    public CloseSession createCloseSession() {
        return new CloseSession();
    }

    /**
     * Create an instance of {@link DeleteRoleResponse }
     * 
     */
    public DeleteRoleResponse createDeleteRoleResponse() {
        return new DeleteRoleResponse();
    }

    /**
     * Create an instance of {@link UpdateOrganization }
     * 
     */
    public UpdateOrganization createUpdateOrganization() {
        return new UpdateOrganization();
    }

    /**
     * Create an instance of {@link AddRole }
     * 
     */
    public AddRole createAddRole() {
        return new AddRole();
    }

    /**
     * Create an instance of {@link GetSessionByTokenResponse }
     * 
     */
    public GetSessionByTokenResponse createGetSessionByTokenResponse() {
        return new GetSessionByTokenResponse();
    }

    /**
     * Create an instance of {@link ListAccountsByOrganization }
     * 
     */
    public ListAccountsByOrganization createListAccountsByOrganization() {
        return new ListAccountsByOrganization();
    }

    /**
     * Create an instance of {@link RememberPassword }
     * 
     */
    public RememberPassword createRememberPassword() {
        return new RememberPassword();
    }

    /**
     * Create an instance of {@link DeleteAccount }
     * 
     */
    public DeleteAccount createDeleteAccount() {
        return new DeleteAccount();
    }

    /**
     * Create an instance of {@link UpdateRole }
     * 
     */
    public UpdateRole createUpdateRole() {
        return new UpdateRole();
    }

    /**
     * Create an instance of {@link UpdateOrganizationResponse }
     * 
     */
    public UpdateOrganizationResponse createUpdateOrganizationResponse() {
        return new UpdateOrganizationResponse();
    }

    /**
     * Create an instance of {@link ListAccountsByOrganizationResponse }
     * 
     */
    public ListAccountsByOrganizationResponse createListAccountsByOrganizationResponse() {
        return new ListAccountsByOrganizationResponse();
    }

    /**
     * Create an instance of {@link DoLogin }
     * 
     */
    public DoLogin createDoLogin() {
        return new DoLogin();
    }

    /**
     * Create an instance of {@link UpdateAccount }
     * 
     */
    public UpdateAccount createUpdateAccount() {
        return new UpdateAccount();
    }

    /**
     * Create an instance of {@link AddOrganizationResponse }
     * 
     */
    public AddOrganizationResponse createAddOrganizationResponse() {
        return new AddOrganizationResponse();
    }

    /**
     * Create an instance of {@link NewRegisterResponse }
     * 
     */
    public NewRegisterResponse createNewRegisterResponse() {
        return new NewRegisterResponse();
    }

    /**
     * Create an instance of {@link ListOrganizationsResponse }
     * 
     */
    public ListOrganizationsResponse createListOrganizationsResponse() {
        return new ListOrganizationsResponse();
    }

    /**
     * Create an instance of {@link CloseSessionResponse }
     * 
     */
    public CloseSessionResponse createCloseSessionResponse() {
        return new CloseSessionResponse();
    }

    /**
     * Create an instance of {@link GetAccountByEmailPasswordResponse }
     * 
     */
    public GetAccountByEmailPasswordResponse createGetAccountByEmailPasswordResponse() {
        return new GetAccountByEmailPasswordResponse();
    }

    /**
     * Create an instance of {@link UpdateRoleResponse }
     * 
     */
    public UpdateRoleResponse createUpdateRoleResponse() {
        return new UpdateRoleResponse();
    }

    /**
     * Create an instance of {@link RememberPasswordResponse }
     * 
     */
    public RememberPasswordResponse createRememberPasswordResponse() {
        return new RememberPasswordResponse();
    }

    /**
     * Create an instance of {@link Organization }
     * 
     */
    public Organization createOrganization() {
        return new Organization();
    }

    /**
     * Create an instance of {@link Role }
     * 
     */
    public Role createRole() {
        return new Role();
    }

    /**
     * Create an instance of {@link Session }
     * 
     */
    public Session createSession() {
        return new Session();
    }

    /**
     * Create an instance of {@link Account }
     * 
     */
    public Account createAccount() {
        return new Account();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccountsByOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listAccountsByOrganization")
    public JAXBElement<ListAccountsByOrganization> createListAccountsByOrganization(ListAccountsByOrganization value) {
        return new JAXBElement<ListAccountsByOrganization>(_ListAccountsByOrganization_QNAME, ListAccountsByOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteAccount")
    public JAXBElement<DeleteAccount> createDeleteAccount(DeleteAccount value) {
        return new JAXBElement<DeleteAccount>(_DeleteAccount_QNAME, DeleteAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RememberPassword }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "rememberPassword")
    public JAXBElement<RememberPassword> createRememberPassword(RememberPassword value) {
        return new JAXBElement<RememberPassword>(_RememberPassword_QNAME, RememberPassword.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRole }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateRole")
    public JAXBElement<UpdateRole> createUpdateRole(UpdateRole value) {
        return new JAXBElement<UpdateRole>(_UpdateRole_QNAME, UpdateRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSessionByTokenResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getSessionByTokenResponse")
    public JAXBElement<GetSessionByTokenResponse> createGetSessionByTokenResponse(GetSessionByTokenResponse value) {
        return new JAXBElement<GetSessionByTokenResponse>(_GetSessionByTokenResponse_QNAME, GetSessionByTokenResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateOrganization")
    public JAXBElement<UpdateOrganization> createUpdateOrganization(UpdateOrganization value) {
        return new JAXBElement<UpdateOrganization>(_UpdateOrganization_QNAME, UpdateOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddRole }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addRole")
    public JAXBElement<AddRole> createAddRole(AddRole value) {
        return new JAXBElement<AddRole>(_AddRole_QNAME, AddRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRoleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteRoleResponse")
    public JAXBElement<DeleteRoleResponse> createDeleteRoleResponse(DeleteRoleResponse value) {
        return new JAXBElement<DeleteRoleResponse>(_DeleteRoleResponse_QNAME, DeleteRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListRoles }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listRoles")
    public JAXBElement<ListRoles> createListRoles(ListRoles value) {
        return new JAXBElement<ListRoles>(_ListRoles_QNAME, ListRoles.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addOrganization")
    public JAXBElement<AddOrganization> createAddOrganization(AddOrganization value) {
        return new JAXBElement<AddOrganization>(_AddOrganization_QNAME, AddOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addAccountResponse")
    public JAXBElement<AddAccountResponse> createAddAccountResponse(AddAccountResponse value) {
        return new JAXBElement<AddAccountResponse>(_AddAccountResponse_QNAME, AddAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getAccountByEmailResponse")
    public JAXBElement<GetAccountByEmailResponse> createGetAccountByEmailResponse(GetAccountByEmailResponse value) {
        return new JAXBElement<GetAccountByEmailResponse>(_GetAccountByEmailResponse_QNAME, GetAccountByEmailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteOrganizationResponse")
    public JAXBElement<DeleteOrganizationResponse> createDeleteOrganizationResponse(DeleteOrganizationResponse value) {
        return new JAXBElement<DeleteOrganizationResponse>(_DeleteOrganizationResponse_QNAME, DeleteOrganizationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRole }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteRole")
    public JAXBElement<DeleteRole> createDeleteRole(DeleteRole value) {
        return new JAXBElement<DeleteRole>(_DeleteRole_QNAME, DeleteRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSession }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "closeSession")
    public JAXBElement<CloseSession> createCloseSession(CloseSession value) {
        return new JAXBElement<CloseSession>(_CloseSession_QNAME, CloseSession.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmailPasswordResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getAccountByEmailPasswordResponse")
    public JAXBElement<GetAccountByEmailPasswordResponse> createGetAccountByEmailPasswordResponse(GetAccountByEmailPasswordResponse value) {
        return new JAXBElement<GetAccountByEmailPasswordResponse>(_GetAccountByEmailPasswordResponse_QNAME, GetAccountByEmailPasswordResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RememberPasswordResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "rememberPasswordResponse")
    public JAXBElement<RememberPasswordResponse> createRememberPasswordResponse(RememberPasswordResponse value) {
        return new JAXBElement<RememberPasswordResponse>(_RememberPasswordResponse_QNAME, RememberPasswordResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRoleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateRoleResponse")
    public JAXBElement<UpdateRoleResponse> createUpdateRoleResponse(UpdateRoleResponse value) {
        return new JAXBElement<UpdateRoleResponse>(_UpdateRoleResponse_QNAME, UpdateRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOrganizationsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listOrganizationsResponse")
    public JAXBElement<ListOrganizationsResponse> createListOrganizationsResponse(ListOrganizationsResponse value) {
        return new JAXBElement<ListOrganizationsResponse>(_ListOrganizationsResponse_QNAME, ListOrganizationsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSessionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "closeSessionResponse")
    public JAXBElement<CloseSessionResponse> createCloseSessionResponse(CloseSessionResponse value) {
        return new JAXBElement<CloseSessionResponse>(_CloseSessionResponse_QNAME, CloseSessionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateAccount")
    public JAXBElement<UpdateAccount> createUpdateAccount(UpdateAccount value) {
        return new JAXBElement<UpdateAccount>(_UpdateAccount_QNAME, UpdateAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addOrganizationResponse")
    public JAXBElement<AddOrganizationResponse> createAddOrganizationResponse(AddOrganizationResponse value) {
        return new JAXBElement<AddOrganizationResponse>(_AddOrganizationResponse_QNAME, AddOrganizationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NewRegisterResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "newRegisterResponse")
    public JAXBElement<NewRegisterResponse> createNewRegisterResponse(NewRegisterResponse value) {
        return new JAXBElement<NewRegisterResponse>(_NewRegisterResponse_QNAME, NewRegisterResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateOrganizationResponse")
    public JAXBElement<UpdateOrganizationResponse> createUpdateOrganizationResponse(UpdateOrganizationResponse value) {
        return new JAXBElement<UpdateOrganizationResponse>(_UpdateOrganizationResponse_QNAME, UpdateOrganizationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccountsByOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listAccountsByOrganizationResponse")
    public JAXBElement<ListAccountsByOrganizationResponse> createListAccountsByOrganizationResponse(ListAccountsByOrganizationResponse value) {
        return new JAXBElement<ListAccountsByOrganizationResponse>(_ListAccountsByOrganizationResponse_QNAME, ListAccountsByOrganizationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoLogin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "doLogin")
    public JAXBElement<DoLogin> createDoLogin(DoLogin value) {
        return new JAXBElement<DoLogin>(_DoLogin_QNAME, DoLogin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoLoginResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "doLoginResponse")
    public JAXBElement<DoLoginResponse> createDoLoginResponse(DoLoginResponse value) {
        return new JAXBElement<DoLoginResponse>(_DoLoginResponse_QNAME, DoLoginResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSessionByToken }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getSessionByToken")
    public JAXBElement<GetSessionByToken> createGetSessionByToken(GetSessionByToken value) {
        return new JAXBElement<GetSessionByToken>(_GetSessionByToken_QNAME, GetSessionByToken.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmailPassword }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getAccountByEmailPassword")
    public JAXBElement<GetAccountByEmailPassword> createGetAccountByEmailPassword(GetAccountByEmailPassword value) {
        return new JAXBElement<GetAccountByEmailPassword>(_GetAccountByEmailPassword_QNAME, GetAccountByEmailPassword.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteOrganization")
    public JAXBElement<DeleteOrganization> createDeleteOrganization(DeleteOrganization value) {
        return new JAXBElement<DeleteOrganization>(_DeleteOrganization_QNAME, DeleteOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListRolesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listRolesResponse")
    public JAXBElement<ListRolesResponse> createListRolesResponse(ListRolesResponse value) {
        return new JAXBElement<ListRolesResponse>(_ListRolesResponse_QNAME, ListRolesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "deleteAccountResponse")
    public JAXBElement<DeleteAccountResponse> createDeleteAccountResponse(DeleteAccountResponse value) {
        return new JAXBElement<DeleteAccountResponse>(_DeleteAccountResponse_QNAME, DeleteAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccounts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listAccounts")
    public JAXBElement<ListAccounts> createListAccounts(ListAccounts value) {
        return new JAXBElement<ListAccounts>(_ListAccounts_QNAME, ListAccounts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOrganizations }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listOrganizations")
    public JAXBElement<ListOrganizations> createListOrganizations(ListOrganizations value) {
        return new JAXBElement<ListOrganizations>(_ListOrganizations_QNAME, ListOrganizations.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddRoleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addRoleResponse")
    public JAXBElement<AddRoleResponse> createAddRoleResponse(AddRoleResponse value) {
        return new JAXBElement<AddRoleResponse>(_AddRoleResponse_QNAME, AddRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListAccountsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "listAccountsResponse")
    public JAXBElement<ListAccountsResponse> createListAccountsResponse(ListAccountsResponse value) {
        return new JAXBElement<ListAccountsResponse>(_ListAccountsResponse_QNAME, ListAccountsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAccountByEmail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "getAccountByEmail")
    public JAXBElement<GetAccountByEmail> createGetAccountByEmail(GetAccountByEmail value) {
        return new JAXBElement<GetAccountByEmail>(_GetAccountByEmail_QNAME, GetAccountByEmail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "updateAccountResponse")
    public JAXBElement<UpdateAccountResponse> createUpdateAccountResponse(UpdateAccountResponse value) {
        return new JAXBElement<UpdateAccountResponse>(_UpdateAccountResponse_QNAME, UpdateAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "addAccount")
    public JAXBElement<AddAccount> createAddAccount(AddAccount value) {
        return new JAXBElement<AddAccount>(_AddAccount_QNAME, AddAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NewRegister }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.security/", name = "newRegister")
    public JAXBElement<NewRegister> createNewRegister(NewRegister value) {
        return new JAXBElement<NewRegister>(_NewRegister_QNAME, NewRegister.class, null, value);
    }

}
