@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws/")
package conector.pbx;
