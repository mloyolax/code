
package conector.pbx;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the conector.pbx package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OnAddAccountResponse_QNAME = new QName("http://ws/", "onAddAccountResponse");
    private final static QName _OnDeleteOrganizationResponse_QNAME = new QName("http://ws/", "onDeleteOrganizationResponse");
    private final static QName _OnAddAccount_QNAME = new QName("http://ws/", "onAddAccount");
    private final static QName _OnDeleteOrganization_QNAME = new QName("http://ws/", "onDeleteOrganization");
    private final static QName _OnDeleteAccount_QNAME = new QName("http://ws/", "onDeleteAccount");
    private final static QName _OnDeleteAccountResponse_QNAME = new QName("http://ws/", "onDeleteAccountResponse");
    private final static QName _OnAddOrganization_QNAME = new QName("http://ws/", "onAddOrganization");
    private final static QName _OnAddOrganizationResponse_QNAME = new QName("http://ws/", "onAddOrganizationResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: conector.pbx
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OnAddOrganizationResponse }
     * 
     */
    public OnAddOrganizationResponse createOnAddOrganizationResponse() {
        return new OnAddOrganizationResponse();
    }

    /**
     * Create an instance of {@link OnAddOrganization }
     * 
     */
    public OnAddOrganization createOnAddOrganization() {
        return new OnAddOrganization();
    }

    /**
     * Create an instance of {@link OnDeleteAccountResponse }
     * 
     */
    public OnDeleteAccountResponse createOnDeleteAccountResponse() {
        return new OnDeleteAccountResponse();
    }

    /**
     * Create an instance of {@link OnDeleteAccount }
     * 
     */
    public OnDeleteAccount createOnDeleteAccount() {
        return new OnDeleteAccount();
    }

    /**
     * Create an instance of {@link OnDeleteOrganization }
     * 
     */
    public OnDeleteOrganization createOnDeleteOrganization() {
        return new OnDeleteOrganization();
    }

    /**
     * Create an instance of {@link OnAddAccount }
     * 
     */
    public OnAddAccount createOnAddAccount() {
        return new OnAddAccount();
    }

    /**
     * Create an instance of {@link OnAddAccountResponse }
     * 
     */
    public OnAddAccountResponse createOnAddAccountResponse() {
        return new OnAddAccountResponse();
    }

    /**
     * Create an instance of {@link OnDeleteOrganizationResponse }
     * 
     */
    public OnDeleteOrganizationResponse createOnDeleteOrganizationResponse() {
        return new OnDeleteOrganizationResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnAddAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onAddAccountResponse")
    public JAXBElement<OnAddAccountResponse> createOnAddAccountResponse(OnAddAccountResponse value) {
        return new JAXBElement<OnAddAccountResponse>(_OnAddAccountResponse_QNAME, OnAddAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onDeleteOrganizationResponse")
    public JAXBElement<OnDeleteOrganizationResponse> createOnDeleteOrganizationResponse(OnDeleteOrganizationResponse value) {
        return new JAXBElement<OnDeleteOrganizationResponse>(_OnDeleteOrganizationResponse_QNAME, OnDeleteOrganizationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnAddAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onAddAccount")
    public JAXBElement<OnAddAccount> createOnAddAccount(OnAddAccount value) {
        return new JAXBElement<OnAddAccount>(_OnAddAccount_QNAME, OnAddAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onDeleteOrganization")
    public JAXBElement<OnDeleteOrganization> createOnDeleteOrganization(OnDeleteOrganization value) {
        return new JAXBElement<OnDeleteOrganization>(_OnDeleteOrganization_QNAME, OnDeleteOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onDeleteAccount")
    public JAXBElement<OnDeleteAccount> createOnDeleteAccount(OnDeleteAccount value) {
        return new JAXBElement<OnDeleteAccount>(_OnDeleteAccount_QNAME, OnDeleteAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnDeleteAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onDeleteAccountResponse")
    public JAXBElement<OnDeleteAccountResponse> createOnDeleteAccountResponse(OnDeleteAccountResponse value) {
        return new JAXBElement<OnDeleteAccountResponse>(_OnDeleteAccountResponse_QNAME, OnDeleteAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnAddOrganization }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onAddOrganization")
    public JAXBElement<OnAddOrganization> createOnAddOrganization(OnAddOrganization value) {
        return new JAXBElement<OnAddOrganization>(_OnAddOrganization_QNAME, OnAddOrganization.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnAddOrganizationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws/", name = "onAddOrganizationResponse")
    public JAXBElement<OnAddOrganizationResponse> createOnAddOrganizationResponse(OnAddOrganizationResponse value) {
        return new JAXBElement<OnAddOrganizationResponse>(_OnAddOrganizationResponse_QNAME, OnAddOrganizationResponse.class, null, value);
    }

}
