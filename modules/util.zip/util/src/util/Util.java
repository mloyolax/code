package util;

import javax.ejb.Singleton;
import conector.security.SecurityWS;
import conector.security.SecurityWSService;
import conector.security.Session;


@Singleton
public class Util {
	
	SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();
	
	
	public SecurityWS getSecurityWS() {
		return securityWS;
	}
	
	
	
	public void closeSession() {
		if(getSession()!=null){
			FacesUtils.setCookie("portaltoken", null);
			securityWS.closeSession(getSession().getToken());
		} 
	}
	
	//Production
		/* 
		public Session getSession() {
			Session result = null;
			String token = FacesUtils.getCookieValue("portaltoken");
			if(token!=null){
				result = securityWS.getSessionByToken(token);
			}
			return result; 
		}
		*/	
	
	//Test
	/*  */
	public Session getSession() {
		String token = securityWS.doLogin("superadmin@virtualskynet.com", "123456");
		return securityWS.getSessionByToken(token);  
	}
	 

}
