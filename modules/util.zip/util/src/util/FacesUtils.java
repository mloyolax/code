package util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


public class FacesUtils {
	
	public static HttpSession getSession() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		return session; 
	}
	
	public static HttpServletRequest getRequest() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		return request; 
	}

	public static String getSessionIp() {
		return getRequest().getRemoteHost();
	}
	
	public static void setSession(String attribute, Object value) {
		getSession().setAttribute(attribute, value);
	}	
	public static Object getSessionAttribute(String attribute) {
		return  getSession().getAttribute(attribute); 
	}
	
	public static void closeSession() {
		getSession().invalidate();
	}
	
	public static ExternalContext getContext() {
		ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
	    return context;
	}
	
	// ------------------------------------------------------------------------------------------------------------------
	
	
	public static String getRequestParameter(String parameter) {
	    Map<String, String> paramMap = getContext().getRequestParameterMap();
	    return paramMap.get(parameter);
	}
	
	public static String getServerAddress() {
	    return getContext().getRequestServerName();
	}

	public static String getServerModule() {
	    return getContext().getRequestContextPath();
	}

	public static String getServerPage() {
	    return getContext().getRequestServletPath();
	}
	
	
	public static void redirect(String url) {
		try {
			getContext().redirect(url);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void setCookie(String key, String value) {
		Map<String, Object> s =  new HashMap <String, Object>();
		s.put("path", "/");
		getContext().addResponseCookie(key, value, s);
	}
	
	public static String getCookieValue(String key) {
		String result = null;
		Map<String, Object> cookies  = getContext().getRequestCookieMap();
		Cookie cookie = (Cookie) cookies.get(key);
		if(cookie!=null){
			result =cookie.getValue();
		}
		return result;
	}
	
	
	
	// ------------------------------------------------------------------------------------------------------------------
	
	public static void setLocale(String localeCode) {
		Locale locale = new Locale(localeCode);
		FacesContext.getCurrentInstance().getViewRoot().setLocale(locale);
	}
	public static String getLocale() {
		Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();
		return locale.getLanguage();	
	}
	
	// ------------------------------------------------------------------------------------------------------------------
	
	public static void addErrorMessage(String clientId, String title, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId,new FacesMessage(FacesMessage.SEVERITY_ERROR, title, msg));
	}

	public static void addInfoMessage(String title, String msg) {
		addInfoMessage(null, title, msg);
	}

	public static void addInfoMessage(String clientId, String title, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_INFO, title, msg));
	}

	public static void addWarnMessage(String title, String msg) {
		addWarnMessage(null, title, msg);
	}

	public static void addWarnMessage(String clientId, String title, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_WARN, title, msg));
	}
	

}
