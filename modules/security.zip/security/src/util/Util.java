package util;

import javax.ejb.Singleton;
import conector.security.SecurityWS;
import conector.security.SecurityWSService;
import conector.security.Session;

@Singleton
public class Util {
	
	SecurityWS securityWS = new SecurityWSService().getSecurityWSPort();
	
	
	public SecurityWS getSecurityWS() {
		return securityWS;
	}
	
	
	//Production
	/*
	public Session getSession() {
		String token = FacesUtils.getCookieValue("virtualskynet");
		return securityWS.getSessionByToken(token); 
	}
	*/
	
	
	//Test
	/**/
	public Session getSession() {
		String token = securityWS.doLogin("superadmin@virtualskynet.com", "123456");
		return securityWS.getSessionByToken(token);  
	}


}
