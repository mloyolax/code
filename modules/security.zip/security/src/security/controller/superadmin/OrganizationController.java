package security.controller.superadmin;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import org.primefaces.event.FileUploadEvent;
import conector.security.Organization;
import util.FacesUtils;
import util.Util;

@SessionScoped
@ManagedBean(name="securitySuperadminOrganization")
public class OrganizationController{
	
	//-------------------------------------------------------------
	List<Organization> data; 
	
	@Inject
	Util util;
		
	@PostConstruct
	public void init() {
		refreshData();
	}
	public void refreshData() {
		data = util.getSecurityWS().listOrganizations(0,0);
	}
	public List<Organization> getData() {
    	return data;
	}
    
	//-------------------------------------------------------------
	Organization row; 	
	public Organization getRow() {
		return row;
	}
	public void setRow(Organization row) {
		this.row = row;
	}
	//-------------------------------------------------------------
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------
	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Organization();
		option = "create.xhtml";
	}
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
        	option = "update.xhtml";	
    	}
	}
    
    public void doCreate() {		
		if(row.getName().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter a Name!!","");
    	}
    	else{	
    		util.getSecurityWS().addOrganization(row);
    		option = "show.xhtml";
    	}		
    }
    
	public void doUpdate() {		
		if(row.getName().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter a Name!!","");
    	}
    	else{	
    		util.getSecurityWS().updateOrganization(row);
    		option = "show.xhtml";
    	}		
    }	
	
	public void doDelete() {
		if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for Delete!!","");
    	}
    	else{
    		util.getSecurityWS().deleteOrganization(row.getId());
    		option = "show.xhtml";
    	}
    }
	
	public void handleFileUpload(FileUploadEvent event) {  
		System.out.println("XS");
    }
	 
	
    
}
