package security.controller.superadmin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import conector.security.Account;
import conector.security.Organization;
import conector.security.Role;
import util.FacesUtils;
import util.Util;

@SessionScoped
@ManagedBean(name="securitySuperadminAccount")
public class AccountController{
	
	//-------------------------------------------------------------
	List<Account> data; 
	
	@Inject
	Util util;
	
	public void refreshData() {
		data = util.getSecurityWS().listAccounts(0,0);
		items1 = util.getSecurityWS().listOrganizations(0,0);
		items2 = util.getSecurityWS().listRoles(0,0);
	}
	
	public List<Account> getData() {
		return data;
	}
	
    //-------------------------------------------------------------
	Account row; 	
	public Account getRow() {
		return row;
	}
	public void setRow(Account row) {
		this.row = row;
	}
	//-------------------------------------------------------------	
 	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------	
	Organization organization = new Organization();
	public Organization getOrganization() {
		return organization;
	}
	List<Organization> items1 = new ArrayList<Organization>();	
	public List<Organization> getItems1() {
		if(row!=null){
			if(row.getOrganization()!=null){
				List<Organization> modified = new ArrayList<Organization>();
				modified.add(row.getOrganization());
				Iterator<Organization> it = items1.iterator();
				while(it.hasNext()){
					Organization tmp = it.next();
					if(!tmp.getId().equals(row.getOrganization().getId())){
						modified.add(tmp);
					}
				}			
				items1 = modified;		
			}
		}
		return items1;
	}

	//-------------------------------------------------------------		
	Role role = new Role();
	public Role getRole() {
		return role;
	}
	List<Role> items2 = new ArrayList<Role>();	
	public List<Role> getItems2() {
		if(row!=null){
			if(row.getRole()!=null){
				List<Role> modified = new ArrayList<Role>();
				modified.add(row.getRole());
				Iterator<Role> it = items2.iterator();
				while(it.hasNext()){
					Role tmp = it.next();
					if(!tmp.getId().equals(row.getRole().getId())){
						modified.add(tmp);
					}
				}			
				items2 = modified;
			}
		}
		return items2;
	}	
	//-------------------------------------------------------------	

	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Account();
		option = "create.xhtml";
	}    
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
        	option = "update.xhtml";	
    	}
	}
    
	public void doCreate() {		
		if(row.getEmail().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Email!!","");
    	}
    	else{
			row.setOrganization(organization);
    		row.setRole(role);
    		util.getSecurityWS().addAccount(row);
    		option = "show.xhtml";
    	}		
    }
	
	public void doUpdate() {		
		if(row.getEmail().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Email!!","");
    	}
    	else{
			row.setOrganization(organization);
    		row.setRole(role);
    		util.getSecurityWS().updateAccount(row);
    		option = "show.xhtml";
    	}		
    }
	
	public void doDelete() {
		if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for Delete!!","");
    	}
    	else{
    		util.getSecurityWS().deleteAccount(row.getId());
    		option = "show.xhtml";
    	}
    }
	    
}
