package security.controller.superadmin;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import conector.security.Role;
import util.FacesUtils;
import util.Util;

@SessionScoped
@ManagedBean(name="securitySuperadminRole")
public class RoleController{
	
	//-------------------------------------------------------------
	List<Role> data; 
	
	@Inject
	Util util;
	
	@PostConstruct
	public void init() {
		refreshData();
	}
	public void refreshData() {
		data = util.getSecurityWS().listRoles(0,0);
	}
    public List<Role> getData() {
		return data;
	}
    //-------------------------------------------------------------
	Role row; 	
	public Role getRow() {
		return row;
	}
	public void setRow(Role row) {
		this.row = row;
	}
	//-------------------------------------------------------------
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------
	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Role();
		option = "create.xhtml";
	}
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
        	option = "update.xhtml";	
    	}
	}
    
    public void doCreate() {		
		if(row.getName().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter a Name!!","");
    	}
    	else{	
    		util.getSecurityWS().addRole(row);
    		option = "show.xhtml";
    	}		
    }
    
	public void doUpdate() {		
		if(row.getName().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter a Name!!","");
    	}
    	else{	
    		util.getSecurityWS().updateRole(row);
    		option = "show.xhtml";
    	}		
    }	
	
	public void doDelete() {
		if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for Delete!!","");
    	}
    	else{
    		util.getSecurityWS().deleteRole(row.getId());
    		option = "show.xhtml";
    	}
    }
	
    
}
