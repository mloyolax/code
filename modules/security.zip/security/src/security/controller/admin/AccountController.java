package security.controller.admin;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import conector.security.Account;
import conector.security.Organization;
import util.FacesUtils;
import util.Util;

@SessionScoped
@ManagedBean(name="securityAdminAccount")
public class AccountController{
	
	List<Account> data; 
	
	@Inject
	Util util;
		
	@PostConstruct
	public void init() {
		refreshData();	
	}
	public void refreshData() {
		Organization organization = util.getSession().getAccount().getOrganization();
		data = util.getSecurityWS().listAccountsByOrganization(organization, 0, 0);
	}	
	
	public List<Account> getData() {
		return data;
	}	
	
    //-------------------------------------------------------------
	Account row;
	public Account getRow() {
		return row;
	}
	public void setRow(Account row) {
		this.row = row;
	}	
	//-------------------------------------------------------------	
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------	

	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onCreate() {
    	this.row = new Account();	
		option = "createupdate.xhtml";
	}    
    public void onUpdate() {
    	if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for update!!","");
    	}
    	else{
        	option = "createupdate.xhtml";	
    	}
	}
   
    public void doCreateUpdate() {    	
    	if(row.getEmail().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Email!!","");
    	}
    	else{
    		util.getSecurityWS().addAccount(row);
    		option = "show.xhtml";
    	}		
    }
	
	public void doDelete() {
		if(row==null){
        	FacesUtils.addErrorMessage("public","You need select a row for Delete!!","");
    	}
    	else{
    		util.getSecurityWS().deleteAccount(row.getId());
    		option = "show.xhtml";
    	}		
    }
	    
}
