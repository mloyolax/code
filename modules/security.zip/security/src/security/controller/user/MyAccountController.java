package security.controller.user;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import conector.security.Account;
import util.FacesUtils;
import util.Util;

@SessionScoped
@ManagedBean(name="securityUserMyaccount")
public class MyAccountController{
	
	@Inject
	Util util;
			
	@PostConstruct
	public void init() {
		refreshData();	
	}
	public void refreshData() {
		row = util.getSession().getAccount();
	}	
	
    //-------------------------------------------------------------
	Account row;
	public Account getRow() {
		return row;
	}
	public void setRow(Account row) {
		this.row = row;
	}	
	
	String oldpassword;	
	public String getOldpassword() {
		return oldpassword;
	}
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	String newpassword;
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	String renewpassword;
	public String getRenewpassword() {
		return renewpassword;
	}
	public void setRenewpassword(String renewpassword) {
		this.renewpassword = renewpassword;
	}	
	
	//-------------------------------------------------------------	
	String option = "show.xhtml";
	public String getOption() {
		refreshData();
		return option;
	}
	//-------------------------------------------------------------	

	public void onCancel() {
		option = "show.xhtml";
	}	
    public void onUpdate() {
		option = "update.xhtml";
	}
    public void onChangePassword() {
		option = "password.xhtml";
	} 
     
    public void doUpdate() {    	
    	if(row.getEmail().isEmpty()){
        	FacesUtils.addErrorMessage("public","Enter an Email!!","");
    	}
    	else{		
    		util.getSecurityWS().updateAccount(row);
    		FacesUtils.addErrorMessage("public","Account Updated!!","");
    		option = "show.xhtml";
    	}		
    }
    
    public void doChangePassword() {    	
    	if(!oldpassword.equals(row.getPassword())){
        	FacesUtils.addErrorMessage("public","Your Old Password dont Match!!","");
    	}
    	else{
    		if(!renewpassword.equals(newpassword)){
            	FacesUtils.addErrorMessage("public","Your New Password dont Match!!","");
        	}
    		else{
    			row.setPassword(newpassword);
    			util.getSecurityWS().updateAccount(row);
        		FacesUtils.addErrorMessage("public","Password Updated!!","");
        		option = "show.xhtml";
    		}
    	}		
    }	    
}
