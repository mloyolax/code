@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.security/")
package conector.security;
